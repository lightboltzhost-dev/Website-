# HetznerCLOUD Paymenter Extension

This extension allows Paymenter v1.2 to sell Hetzner Cloud servers. It is built mainly around the [api.hetzner.cloud](https://api.hetzner.cloud) API, enabling automated provisioning and management of Hetzner Cloud servers directly from Paymenter.

**Note:** This extension is designed for the newest version of Paymenter (v1.2).
