<div class="alert alert-danger">
    <h4>Error</h4>
    <p>{{ $error }}</p>
</div>
