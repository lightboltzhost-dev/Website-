<?php

// Routes are loaded automatically by the extension system
// No additional routes needed for basic functionality
