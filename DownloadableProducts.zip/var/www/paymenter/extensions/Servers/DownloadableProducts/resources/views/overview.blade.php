@php
    $expiryDays = isset($settings['download_expiry']) ? (int)$settings['download_expiry'] : 0;
    $expiryDate = $expiryDays > 0 ? $service->created_at->addDays($expiryDays) : null;
@endphp


<div class="download-info">
    <p><strong>Download Count:</strong> {{ $service->download_count }} / 
        {{ $settings['download_limit'] > 0 ? $settings['download_limit'] : '∞' }}</p>

    @if($expiryDate)
        <p><strong>Expires on:</strong> {{ $expiryDate->format('Y-m-d H:i:s') }}</p>
        <p id="download-timer">Time remaining: <span></span></p>
    @endif

    <a href="{{ route('service.download', $service->id) }}" class="btn btn-primary">Download File</a>
</div>

@if($expiryDate)
<script>
const expiry = new Date("{{ $expiryDate->toIsoString() }}").getTime();
const timerEl = document.querySelector('#download-timer span');
const interval = setInterval(() => {
    const now = new Date().getTime();
    const distance = expiry - now;
    if (distance < 0) {
        clearInterval(interval);
        timerEl.innerText = 'Expired';
        return;
    }
    const days = Math.floor(distance / (1000*60*60*24));
    const hours = Math.floor((distance % (1000*60*60*24)) / (1000*60*60));
    const minutes = Math.floor((distance % (1000*60*60)) / (1000*60));
    const seconds = Math.floor((distance % (1000*60)) / 1000);
    timerEl.innerText = `${days}d ${hours}h ${minutes}m ${seconds}s`;
}, 1000);
</script>
@endif
