<?php

namespace Paymenter\Extensions\Gateways\PayU;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Helpers\ExtensionHelper;
use App\Classes\Extension\Gateway;
use Illuminate\Support\Facades\View;

class PayU extends Gateway
{
    public function boot()
    {
        require __DIR__ . '/routes/web.php';
        View::addNamespace('extensions.gateways.payu', __DIR__ . '/views');
    }

    public function getConfig($values = [])
    {
        return [
            ['name' => 'merchant_key', 'label' => 'Merchant API Key', 'type' => 'text', 'required' => true],
            ['name' => 'merchant_salt', 'label' => 'Merchant Salt', 'type' => 'text', 'required' => true],
            ['name' => 'test_api_key', 'label' => 'Test API Key', 'type' => 'text', 'required' => false],
            ['name' => 'test_salt', 'label' => 'Test Salt', 'type' => 'text', 'required' => false],
            ['name' => 'test_mode', 'label' => 'Test Mode', 'type' => 'checkbox', 'required' => false],
        ];
    }

    public function pay($invoice, $total)
    {
        if ($invoice->currency_code !== 'INR') {
            return view('extensions.gateways.cashfree::error', [
                'error' => 'The product currency must be "INR" to use PayU!',
            ]);
        }

        $key = $this->config('test_mode') ? $this->config('test_api_key') : $this->config('merchant_key');
        $salt = $this->config('test_mode') ? $this->config('test_salt') : $this->config('merchant_salt');
        $url = $this->config('test_mode') ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment';

        $invoiceId = $invoice->id;
        $productInfo = $invoice->items->first()->reference->product->name;
        $name = $invoice->user->name;
        $email = $invoice->user->email;
        $phone = $invoice->user->phone;
        $surl = route('extensions.gateways.payu.success');
        $furl = route('extensions.gateways.payu.fail');

        $hashString = $key . '|' . $invoiceId . '|' . $total . '|' . $productInfo . '|' . $name . '|' . $email . '|||||||||||' . $salt;
        $hash = hash('sha512', $hashString);

        return view('extensions.gateways.payu::pay', compact(
            'url',
            'key',
            'hash',
            'invoiceId',
            'productInfo',
            'total',
            'name',
            'email',
            'phone',
            'surl',
            'furl',
        ));
    }

    public function success(Request $request)
    {
        $txnid = $request->input('txnid');
        $amount = $request->input('amount');
        $invoiceId = (int)$txnid;

        $key = $this->config('test_mode') ? $this->config('test_api_key') : $this->config('merchant_key');
        $salt = $this->config('test_mode') ? $this->config('test_salt') : $this->config('merchant_salt');
        $url = $this->config('test_mode')
            ? 'https://test.payu.in/merchant/postservice?form=2'
            : 'https://info.payu.in/merchant/postservice?form=2';

        $hash = hash('sha512', "$key|verify_payment|$txnid|$salt");

        $client = new Client();
        $response = $client->post($url, [
            'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
            'form_params' => [
                'key' => $key,
                'command' => 'verify_payment',
                'var1' => $txnid,
                'hash' => $hash,
            ],
        ]);

        $data = json_decode($response->getBody(), true);

        if (($data['transaction_details'][$txnid]['status'] ?? '') === 'success') {
            ExtensionHelper::addPayment($invoiceId, 'PayU', $amount, null, $txnid);
        }

        return redirect()->route('invoices.show', ['invoice' => $invoiceId]);
    }

    public function fail(Request $request)
    {
        return redirect()->route('invoices.show', ['invoice' => (int)$request->input('txnid')]);
    }
}
