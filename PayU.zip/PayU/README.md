# PayU Payment Gateway for Paymenter

![](https://upload.wikimedia.org/wikipedia/en/9/99/PayU_Corporate_Logo.png)

A seamless PayU integration for Paymenter, enabling secure and efficient payment processing for your customers.

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](https://github.com/Sarthak-07/PayU-Paymenter/blob/main/LICENSE)
[![Compatibility Paymenter v1.x](https://img.shields.io/badge/Paymenter-v1.x-4B32C3.svg)](https://paymenter.org)

## Prerequisites

- Paymenter v1.x
- PayU Merchant Account

## Setup

1. **Install PayU Gateway Extension:** (Replace `/var/www/paymenter` with your paymenter root if it is different)
   - **Automatic Installation:** `git clone https://github.com/Sarthak-07/PayU-Paymenter.git /var/www/paymenter/extensions/Gateways/PayU`
   - **Manual Installation:** [Download](https://github.com/Sarthak-07/PayU-Paymenter/releases/latest/download/PayU.zip) the extension and extract it in `/var/www/paymenter/extensions/Gateways`
2. **Enable PayU Gateway Extension:** Navigate to `Admin → Gateways → New Gateway → PayU` in Paymenter and follow the Configuration steps.

## Configuration

1. **Merchant API Key:** Get PayU Merchant API Key from [here](https://docs.payu.in/docs/generate-merchant-key-and-salt-on-payu-dashboard)

2. **Merchant Salt:** Get PayU Merchant Salt from [here](https://docs.payu.in/docs/generate-merchant-key-and-salt-on-payu-dashboard)

3. **Test API Key (optional):** Get PayU Test API Key from [here](https://docs.payu.in/docs/generate-test-merchant-key-and-salt)

4. **Test Salt (optional):** Get PayU Test Salt from [here](https://docs.payu.in/docs/generate-test-merchant-key-and-salt)

5. **Test Mode (optional):** Enable this if you want to test PayU Gateway Extension

Congratulations! Your PayU Payment Gateway Configuration is now complete!

## Support

For assistance, please reach out to me on Discord: [@sarthak77](https://discord.com/users/877064899065446461).
