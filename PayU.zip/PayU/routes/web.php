<?php

use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Gateways\PayU\PayU;

Route::post(
    '/extensions/gateways/payu/success',
    [PayU::class, 'success']
)->name('extensions.gateways.payu.success');

Route::post(
    '/extensions/gateways/payu/fail',
    [PayU::class, 'fail']
)->name('extensions.gateways.payu.fail');
