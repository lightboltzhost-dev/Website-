<form id="PayUForm" method="POST" action="{{ $url }}" x-data x-init="$nextTick(() => $el.submit())">
    @csrf
    <input type="hidden" name="key" value="{{ $key }}">
    <input type="hidden" name="hash" value="{{ $hash }}">
    <input type="hidden" name="txnid" value="{{ $invoiceId }}">
    <input type="hidden" name="productinfo" value="{{ $productInfo }}">
    <input type="hidden" name="amount" value="{{ $total }}">
    <input type="hidden" name="firstname" value="{{ $name }}">
    <input type="hidden" name="email" value="{{ $email }}">
    <input type="hidden" name="phone" value="{{ $phone }}">
    <input type="hidden" name="surl" value="{{ $surl }}">
    <input type="hidden" name="furl" value="{{ $furl }}">
</form>