<x-app-layout>
    <x-slot name="title">
        {{ __('errors.404.title') }}
    </x-slot>

    <div class="min-h-[calc(100vh-12rem)] flex items-center justify-center px-6 py-24">
        <div class="max-w-xl w-full space-y-8 text-center">
            <div
                class="inline-flex items-center gap-3 px-4 py-2 rounded-full border border-primary/20 bg-primary/10 text-primary">
                <x-ri-compass-3-line class="size-5" />
                <span class="text-sm font-semibold tracking-wide">404</span>
            </div>

            <div class="space-y-4">
                <h1 class="text-4xl sm:text-5xl font-bold text-base">{{ __('errors.404.title') }}</h1>
                <p class="text-base/70 text-lg">{{ __('errors.404.message') }}</p>
            </div>

            <div class="bg-background-secondary border border-neutral/20 rounded-2xl shadow-sm p-8 space-y-6">
                <div class="flex justify-center">
                    <div class="bg-primary/10 border border-primary/20 rounded-2xl p-4">
                        <x-ri-map-pin-line class="size-8 text-primary" />
                    </div>
                </div>

                <p class="text-base/60 text-sm">{{ __('errors.404.message') }}</p>

                <a href="{{ route('home') }}" wire:navigate class="w-full sm:w-auto inline-block">
                    <x-button.primary class="w-full sm:w-auto">
                        <x-ri-arrow-left-line class="size-4" />
                        {{ __('errors.404.return_home') }}
                    </x-button.primary>
                </a>
            </div>
        </div>
    </div>
</x-app-layout>
