## Security Policy

To report a vulnerability, please use the **Security** tab on this repository or email **report@26bz.online**.  
All reports are reviewed and addressed promptly.
