Thanks for using this free Paymenter extension by Buzz Development!

If you need a great theme to use for Paymenter, we have two amazing options for you:
- https://builtbybit.com/resources/luna-premium-paymenter-theme.73392/
- https://builtbybit.com/resources/cosmos-modern-paymenter-theme.76370/

Also, if you're looking to add fully custom pages to your Paymenter site, consider using our PageBuilder extension!
- https://builtbybit.com/resources/pagebuilder-for-paymenter.77603/

For support or suggestions please join our Discord server: https://discord.gg/buzz

Enjoy!

Installation:
- Upload the extension folder unzipped to `extensions/Others`, or install it via the admin panel in Paymenter
- Enable the extension then enter your Google Analytics tracking measurement ID, and click save
- All done!