<?php

namespace Paymenter\Extensions\Others\Tawkto;

use App\Classes\Extension\Extension;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\HtmlString;

#[ExtensionMeta(
    name: 'Tawkto',
    description: 'Integrates Tawk.to live chat widget into your site for real-time customer support.',
    version: '1.1',
    author: 'QKingsoftware'
)]
class Tawkto extends Extension
{
    public function getName(): string
    {
        return 'Tawk.to Live Chat';
    }

    public function getDescription(): string
    {
        return 'Integrates Tawk.to live chat widget into your site for real-time customer support.';
    }

    public function getVersion(): string
    {
        return '1.0';
    }

    public function getAuthor(): string
    {
        return 'QKingsoftware';
    }

    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'property_id',
                'type' => 'text',
                'label' => 'Tawk.to Property ID',
                'description' => 'Your Tawk.to Property ID (found in Tawk.to dashboard → Admin → Channels → Chat Widget → Widget ID).',
                'required' => true,
                'value' => $values['property_id'] ?? '',
            ],
            [
                'name' => 'widget_id',
                'type' => 'text',
                'label' => 'Tawk.to Widget ID',
                'description' => 'Your Tawk.to Widget ID (found in Tawk.to dashboard → Admin → Overview → Property ID).',
                'required' => true,
                'value' => $values['widget_id'] ?? '',
            ],
        ];
    }

    public function boot(): void
    {
        // Only GET not fucking POST like I did by accident....
        if (!request()->isMethod('GET')) {
            return;
        }

        $propertyId = $this->config('property_id');
        $widgetId   = $this->config('widget_id');

        // No IDs? No widget. Sad.
        if (empty($propertyId) || empty($widgetId)) {
            return;
        }

        $script = $this->getTawktoScript($propertyId, $widgetId);

        // Democracy is cancelled: force injection into <head>
        Event::listen('head', function () use ($script) {
            return ['view' => new HtmlString($script)];
        });
    }

    private function getTawktoScript(string $propertyId, string $widgetId): string
    {
        return <<<HTML
<!-- Tawk.to Live Chat Widget -->
<script type="text/javascript">
(function(){
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    var s1=document.createElement("script");
    s1.async=true;
    s1.src='https://embed.tawk.to/{$propertyId}/{$widgetId}';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    document.getElementsByTagName("head")[0].appendChild(s1);
})();
</script>
<!-- End of Tawk.to Live Chat (go talk to your users now) -->
HTML;
    }

    public function enabled(): void {}
    public function disabled(): void {}
    public function updated(): void {}
    public function install(): void {}
}
