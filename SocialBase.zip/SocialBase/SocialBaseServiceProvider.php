<?php

namespace Paymenter\Extensions\Others\SocialBase;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Others\SocialBase\Admin\AdminServiceProvider;

class SocialBaseServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register the AdminServiceProvider
        $this->app->register(AdminServiceProvider::class);
    }

    public function boot(): void
    {
        // Load migrations
        $this->loadMigrationsFrom(__DIR__ . '/database/migrations');
        
        // Load views
        $this->loadViewsFrom(__DIR__ . '/resources/views', 'socialbase');
        
        // Load routes
        $this->loadRoutesFrom(__DIR__ . '/routes/web.php');
        
        // Publish assets if needed
        $this->publishes([
            __DIR__ . '/resources/views' => resource_path('views/vendor/socialbase'),
        ], 'socialbase-views');
    }
}