# 🚀 SocialBase Extension Installation Guide

This guide installs the **SocialBase** extension for Paymenter. SocialBase is the foundation extension that provides user profiles, messaging, and social features.

---

## ⚡ Quick Install

### Single Line Install
```bash
php artisan migrate --path=extensions/Others/SocialBase/database/migrations --force && npm run build && php artisan config:clear && php artisan view:clear && php artisan cache:clear && php artisan route:clear
```

---

## 🧱 Step-by-Step Installation

### 1) Prepare
```bash
cd /var/www/paymenter
sudo chown -R www-data:www-data .
sudo chmod -R 755 .
```
Make sure `.env` is configured and the site loads.

### 2) Upload Extension
Place the SocialBase folder in `extensions/Others/`:

```
extensions/Others/
└── SocialBase/
    ├── SocialBase.php
    ├── database/migrations/
    ├── resources/
    ├── Admin/
    ├── Livewire/
    ├── Models/
    └── Policies/
```

### 3) Run Migrations
```bash
php artisan migrate --path=extensions/Others/SocialBase/database/migrations --force
```

### 4) Build Assets
Using **NPM** (default):
```bash
( [ -f package-lock.json ] && npm ci || npm install )
npm run build
```

Using **Yarn** (optional):
```bash
( [ -f yarn.lock ] && yarn install --frozen-lockfile || yarn install )
yarn build
```

### 5) Clear Caches
```bash
php artisan config:clear
php artisan view:clear
php artisan cache:clear
php artisan route:clear
```

### 6) Enable in Admin
1. Login → **Admin Panel → Extensions → Others**
2. Enable **SocialBase** ✅
3. Configure settings as needed

> **Note:** SocialBase should be enabled **first** before Reviews or Forum, as they depend on it.

### 7) Configuration
- **User Profiles**: Avatar/banner settings, profile customization
- **Messaging**: Private messaging preferences
- **Social Features**: Comments, reactions, notifications

---

## ✅ Verify Installation

```bash
# Routes contain social features?
php artisan route:list | grep -Ei 'social|profile|message'

# Tables exist?
mysql -u root -p -e "USE paymenter; SHOW TABLES LIKE '%user_profiles%';"

# Frontend rebuilt?
[ -d public/build ] && echo 'Assets built ✔' || echo 'Build missing ✖'
```

---

## 🧯 Troubleshooting

- **"Extension not visible"** → Clear caches (`php artisan view:clear && php artisan cache:clear`), then re-check admin panel.
- **DB errors** → Confirm `.env` DB credentials, run migrations again.
- **Styles missing** → Rebuild assets (`npm run build` or `yarn build`) and hard refresh the browser.
- **Permission denied** → Re-apply `chown`/`chmod` from Step 1.

---

## 🎉 Done
SocialBase is now installed! You can now install Reviews and Forum extensions which depend on this foundation.

