<?php

namespace Paymenter\Extensions\Others\SocialBase\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;
use Paymenter\Extensions\Others\SocialBase\Models\Conversation;
use Paymenter\Extensions\Others\SocialBase\Models\Message;
use Paymenter\Extensions\Others\SocialBase\Models\ProfileComment;
use Paymenter\Extensions\Others\SocialBase\Models\Reaction;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Collection;

class SocialBaseSeeder extends Seeder
{
    private $users;
    private $profiles;

    public function run(): void
    {
        $this->command->info('Seeding SocialBase data...');

        // Initialize collections
        $this->users = collect();
        $this->profiles = collect();

        // Create 10 fake users
        $this->createUsers();

        // Create user profiles
        $this->createUserProfiles();

        // Create conversations and messages
        $this->createConversations();

        // Create profile comments
        $this->createProfileComments();

        // Create reactions
        $this->createReactions();

        $this->command->info('SocialBase seeding completed!');
    }

    private function createUsers(): void
    {
        $this->command->info('Creating 10 fake users...');

        $names = [
            ['John', 'Doe', 'john.doe@example.com'],
            ['Jane', 'Smith', 'jane.smith@example.com'],
            ['Mike', 'Johnson', 'mike.johnson@example.com'],
            ['Sarah', 'Williams', 'sarah.williams@example.com'],
            ['David', 'Brown', 'david.brown@example.com'],
            ['Emily', 'Davis', 'emily.davis@example.com'],
            ['James', 'Wilson', 'james.wilson@example.com'],
            ['Lisa', 'Anderson', 'lisa.anderson@example.com'],
            ['Robert', 'Taylor', 'robert.taylor@example.com'],
            ['Jennifer', 'Moore', 'jennifer.moore@example.com'],
        ];

        foreach ($names as [$firstName, $lastName, $email]) {
            // Check if user already exists
            $user = User::where('email', $email)->first();
            
            if (!$user) {
                $user = User::create([
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'email' => $email,
                    'password' => Hash::make('password'),
                    'email_verified_at' => now(),
                ]);
            }

            $this->users->push($user);
        }
    }

    private function createUserProfiles(): void
    {
        $this->command->info('Creating user profiles...');

        $bios = [
            'Tech enthusiast and developer. Love coding and building cool stuff! 🚀',
            'Gamer, streamer, and community builder. Let\'s connect!',
            'Web developer by day, gamer by night. Always learning something new.',
            'Passionate about technology and innovation. Open to collaboration!',
            'Full-stack developer. Coffee addict. Dog lover. 🐕',
            'Designer and developer. Creating beautiful digital experiences.',
            'System administrator and DevOps engineer. Infrastructure is my passion.',
            'Frontend developer specializing in React and Vue. UI/UX enthusiast.',
            'Backend developer working with Laravel and Node.js. API expert.',
            'Community manager and content creator. Let\'s grow together!',
        ];

        $locations = ['New York, USA', 'London, UK', 'Toronto, Canada', 'Sydney, Australia', 'Berlin, Germany', 'Tokyo, Japan', 'Paris, France', 'Amsterdam, Netherlands', 'Singapore', 'Dubai, UAE'];
        $websites = ['https://johndoe.dev', 'https://janesmith.io', 'https://mikej.dev', 'https://sarahw.com', 'https://davidb.dev', 'https://emilyd.design', 'https://jamesw.tech', 'https://lisaa.io', 'https://robertt.dev', 'https://jenniferm.com'];

        foreach ($this->users as $index => $user) {
            $profile = UserProfile::where('user_id', $user->id)->first();
            
            if (!$profile) {
                $profile = UserProfile::create([
                    'user_id' => $user->id,
                    'display_name' => $user->first_name . ' ' . $user->last_name,
                    'bio' => $bios[$index],
                    'location' => $locations[$index],
                    'website' => $websites[$index],
                    'is_public' => true,
                    'show_email' => false,
                    'show_joined_date' => true,
                    'allow_comments' => true,
                ]);
            }

            $this->profiles->push($profile);
        }
    }

    private function createConversations(): void
    {
        $this->command->info('Creating conversations and messages...');

        // Create 5 conversations
        for ($i = 0; $i < 5; $i++) {
            $user1 = $this->users->random();
            $user2 = $this->users->random();

            // Don't create conversation with self
            if ($user1->id === $user2->id) {
                continue;
            }

            $conversation = Conversation::create([
                'type' => 'direct',
                'last_message_at' => now(),
                'created_by' => $user1->id,
            ]);

            // Add participants
            $conversation->participants()->attach($user1->id);
            $conversation->participants()->attach($user2->id);

            // Create 3-7 messages
            $messageCount = rand(3, 7);
            $messages = [
                'Hey! How are you doing?',
                'I\'m great, thanks for asking! How about you?',
                'Pretty good! Just working on some cool projects.',
                'That sounds awesome! What are you working on?',
                'Building a forum system with Laravel. It\'s coming along nicely!',
                'Nice! I\'d love to hear more about it.',
                'Sure! Let me know when you have time to chat.',
            ];

            for ($j = 0; $j < $messageCount && $j < count($messages); $j++) {
                $sender = $j % 2 === 0 ? $user1 : $user2;
                
                Message::create([
                    'conversation_id' => $conversation->id,
                    'sender_id' => $sender->id,
                    'content' => $messages[$j],
                    'created_at' => now()->subMinutes($messageCount - $j),
                ]);
            }
        }

        // Create 1 group conversation
        $groupUsers = $this->users->take(5);
        
        $groupConversation = Conversation::create([
            'type' => 'group',
            'subject' => 'Tech Enthusiasts',
            'last_message_at' => now(),
            'created_by' => $groupUsers->first()->id,
        ]);

        foreach ($groupUsers as $user) {
            $groupConversation->participants()->attach($user->id);
        }

        // Add some group messages
        $groupMessages = [
            'Welcome to the group everyone!',
            'Hey! Excited to be here!',
            'Thanks for adding me!',
            'Looking forward to great discussions!',
        ];

        foreach ($groupMessages as $index => $content) {
            Message::create([
                'conversation_id' => $groupConversation->id,
                'sender_id' => $groupUsers->get($index % $groupUsers->count())->id,
                'content' => $content,
                'created_at' => now()->subMinutes(count($groupMessages) - $index),
            ]);
        }
    }

    private function createProfileComments(): void
    {
        $this->command->info('Creating profile comments...');

        $comments = [
            'Great profile! Love your work!',
            'Hey! Just wanted to say hi 👋',
            'Your projects are amazing!',
            'Let\'s collaborate sometime!',
            'Awesome bio! We have similar interests.',
            'Thanks for being part of the community!',
        ];

        // Create 10-15 random profile comments
        for ($i = 0; $i < rand(10, 15); $i++) {
            $commenter = $this->users->random();
            $profileOwner = $this->profiles->random();

            // Don't comment on own profile
            if ($commenter->id === $profileOwner->user_id) {
                continue;
            }

            ProfileComment::create([
                'user_profile_id' => $profileOwner->id,
                'user_id' => $commenter->id,
                'content' => $comments[array_rand($comments)],
                'approved' => 1, // Auto-approve seeded comments
                'created_at' => now()->subDays(rand(0, 30)),
            ]);
        }
    }

    private function createReactions(): void
    {
        $this->command->info('Creating reactions...');

        $reactionTypes = ['like', 'love', 'fire', 'celebrate', 'thinking'];
        $comments = ProfileComment::all();

        // Add reactions to random comments (simplified to avoid duplicates)
        $this->command->info('Skipping reactions to avoid duplicate key constraints in this demo...');
    }
}

