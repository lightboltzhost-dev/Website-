<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('ext_social_profile_comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_profile_id')->constrained('ext_social_user_profiles')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('parent_id')->nullable()->constrained('ext_social_profile_comments')->onDelete('cascade');
            $table->text('content');
            $table->boolean('approved')->default(false);
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // Indexes
            $table->index(['user_profile_id', 'approved']);
            $table->index(['user_id']);
            $table->index(['parent_id']);
            $table->index(['created_at']);
            $table->index(['approved']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('ext_social_profile_comments');
    }
};