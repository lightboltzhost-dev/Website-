<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ext_social_reactions', function (Blueprint $table) {
            $table->id();
            $table->string('reactable_type'); // Model class name (e.g., ProfileComment, ForumPost, etc.)
            $table->unsignedBigInteger('reactable_id'); // Model ID
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('type', 20); // like, love, laugh, angry, sad, etc.
            $table->timestamps();
            
            // Prevent duplicate reactions from same user on same item
            $table->unique(['reactable_type', 'reactable_id', 'user_id']);
            
            // Optimize queries
            $table->index(['reactable_type', 'reactable_id']);
            $table->index(['reactable_type', 'reactable_id', 'type']);
            $table->index(['user_id', 'type']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ext_social_reactions');
    }
};