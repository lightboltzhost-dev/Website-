<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Check if column doesn't exist before adding
        if (!Schema::hasColumn('ext_social_conversations', 'created_by')) {
            Schema::table('ext_social_conversations', function (Blueprint $table) {
                $table->foreignId('created_by')->nullable()->after('subject')->constrained('users')->nullOnDelete();
            });
        }

        if (!Schema::hasColumn('ext_social_conversations', 'last_message_at')) {
            Schema::table('ext_social_conversations', function (Blueprint $table) {
                $table->timestamp('last_message_at')->nullable()->after('created_by');
            });
        }

        if (!Schema::hasColumn('ext_social_conversations', 'metadata')) {
            Schema::table('ext_social_conversations', function (Blueprint $table) {
                $table->json('metadata')->nullable()->after('last_message_at');
            });
        }
    }

    public function down(): void
    {
        Schema::table('ext_social_conversations', function (Blueprint $table) {
            if (Schema::hasColumn('ext_social_conversations', 'created_by')) {
                $table->dropForeign(['created_by']);
                $table->dropColumn('created_by');
            }
            if (Schema::hasColumn('ext_social_conversations', 'last_message_at')) {
                $table->dropColumn('last_message_at');
            }
            if (Schema::hasColumn('ext_social_conversations', 'metadata')) {
                $table->dropColumn('metadata');
            }
        });
    }
};

