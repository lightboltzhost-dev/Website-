<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            $table->string('moderation_status')->default('active')->after('allow_comments');
            $table->text('moderation_notes')->nullable()->after('moderation_status');
        });
    }

    public function down(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            $table->dropColumn(['moderation_status', 'moderation_notes']);
        });
    }
};

