<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ext_social_comment_reactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_comment_id')->constrained('ext_social_profile_comments')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('type', 20); // like, love, laugh, angry, sad, etc.
            $table->timestamps();
            
            // Prevent duplicate reactions from same user on same comment
            $table->unique(['profile_comment_id', 'user_id']);
            
            $table->index(['profile_comment_id', 'type']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ext_social_comment_reactions');
    }
};