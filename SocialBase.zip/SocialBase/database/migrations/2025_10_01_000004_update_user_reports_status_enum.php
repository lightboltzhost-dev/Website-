<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Change the enum to support the new status values
        DB::statement("ALTER TABLE `ext_social_user_reports` MODIFY `status` VARCHAR(50) NOT NULL DEFAULT 'pending'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE `ext_social_user_reports` MODIFY `status` ENUM('pending', 'reviewed', 'dismissed') NOT NULL DEFAULT 'pending'");
    }
};

