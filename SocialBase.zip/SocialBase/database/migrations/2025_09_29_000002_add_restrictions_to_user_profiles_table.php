<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            // Add restriction columns
            $table->boolean('is_banned')->default(false)->after('allow_comments');
            $table->boolean('upload_restricted')->default(false)->after('is_banned');
            $table->boolean('comment_restricted')->default(false)->after('upload_restricted');
            $table->boolean('profile_edit_restricted')->default(false)->after('comment_restricted');
            
            // Add restriction reason and level
            $table->text('restriction_reason')->nullable()->after('profile_edit_restricted');
            $table->enum('restriction_level', ['none', 'warning', 'limited', 'suspended', 'banned'])
                  ->default('none')->after('restriction_reason');
            
            // Add theme column
            $table->string('theme', 50)->default('default')->after('restriction_level');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'is_banned',
                'upload_restricted', 
                'comment_restricted',
                'profile_edit_restricted',
                'restriction_reason',
                'restriction_level',
                'theme'
            ]);
        });
    }
};