<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            // Change default value for is_public to false (private by default)
            $table->boolean('is_public')->default(false)->change();
        });
        
        // Update existing profiles to be private if they haven't been set up
        DB::table('ext_social_user_profiles')
            ->whereNull('display_name')
            ->whereNull('bio')
            ->whereNull('avatar_path')
            ->whereNull('banner_path')
            ->update(['is_public' => false]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ext_social_user_profiles', function (Blueprint $table) {
            $table->boolean('is_public')->default(true)->change();
        });
    }
};