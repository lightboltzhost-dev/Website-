<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Migrate existing comment reactions to the generic reactions table
        $commentReactions = DB::table('ext_social_comment_reactions')->get();
        
        foreach ($commentReactions as $reaction) {
            DB::table('ext_social_reactions')->insert([
                'reactable_type' => 'Paymenter\\Extensions\\Others\\SocialBase\\Models\\ProfileComment',
                'reactable_id' => $reaction->profile_comment_id,
                'user_id' => $reaction->user_id,
                'type' => $reaction->type,
                'created_at' => $reaction->created_at,
                'updated_at' => $reaction->updated_at,
            ]);
        }
        
        // Drop the old comment-specific reactions table
        Schema::dropIfExists('ext_social_comment_reactions');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Recreate the old comment reactions table
        Schema::create('ext_social_comment_reactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_comment_id')->constrained('ext_social_profile_comments')->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('type', 20);
            $table->timestamps();
            
            $table->unique(['profile_comment_id', 'user_id']);
            $table->index(['profile_comment_id', 'type']);
        });
        
        // Migrate data back from generic reactions table
        $genericReactions = DB::table('ext_social_reactions')
            ->where('reactable_type', 'Paymenter\\Extensions\\Others\\SocialBase\\Models\\ProfileComment')
            ->get();
            
        foreach ($genericReactions as $reaction) {
            DB::table('ext_social_comment_reactions')->insert([
                'profile_comment_id' => $reaction->reactable_id,
                'user_id' => $reaction->user_id,
                'type' => $reaction->type,
                'created_at' => $reaction->created_at,
                'updated_at' => $reaction->updated_at,
            ]);
        }
        
        // Remove the generic reactions for comments
        DB::table('ext_social_reactions')
            ->where('reactable_type', 'Paymenter\\Extensions\\Others\\SocialBase\\Models\\ProfileComment')
            ->delete();
    }
};