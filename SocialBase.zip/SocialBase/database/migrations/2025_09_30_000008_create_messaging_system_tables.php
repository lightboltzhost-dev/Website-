<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Conversations table
        Schema::create('ext_social_conversations', function (Blueprint $table) {
            $table->id();
            $table->string('type')->default('direct'); // direct, group, system
            $table->string('subject')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('last_message_at')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            $table->index('type');
            $table->index('last_message_at');
        });

        // Conversation participants
        Schema::create('ext_social_conversation_participants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('conversation_id')->constrained('ext_social_conversations')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamp('last_read_at')->nullable();
            $table->boolean('is_muted')->default(false);
            $table->boolean('is_archived')->default(false);
            $table->timestamps();
            
            $table->unique(['conversation_id', 'user_id'], 'social_conv_part_unique');
            $table->index('user_id');
        });

        // Messages table
        Schema::create('ext_social_messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('conversation_id')->constrained('ext_social_conversations')->cascadeOnDelete();
            $table->foreignId('sender_id')->nullable()->constrained('users')->nullOnDelete();
            $table->text('content');
            $table->string('type')->default('text'); // text, system, notification
            $table->boolean('is_system')->default(false);
            $table->string('system_type')->nullable(); // order_update, payment_received, etc.
            $table->json('metadata')->nullable();
            $table->boolean('is_moderated')->default(false);
            $table->string('moderation_status')->nullable(); // approved, flagged, deleted
            $table->foreignId('moderated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('moderated_at')->nullable();
            $table->text('moderation_reason')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            $table->index('conversation_id');
            $table->index('sender_id');
            $table->index('is_system');
            $table->index('moderation_status');
            $table->index('created_at');
        });

        // Message read receipts
        Schema::create('ext_social_message_reads', function (Blueprint $table) {
            $table->id();
            $table->foreignId('message_id')->constrained('ext_social_messages')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamp('read_at');
            
            $table->unique(['message_id', 'user_id']);
            $table->index('user_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_social_message_reads');
        Schema::dropIfExists('ext_social_messages');
        Schema::dropIfExists('ext_social_conversation_participants');
        Schema::dropIfExists('ext_social_conversations');
    }
};

