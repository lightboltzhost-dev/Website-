<div class="container mx-auto px-4 py-12 max-w-4xl">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        <div class="p-6 border-b border-gray-200 dark:border-gray-700">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
                <i class="ri-settings-line mr-3"></i>
                Profile Settings
            </h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Manage your profile privacy and preferences</p>
        </div>
        
        @if (session()->has('message'))
            <div class="mx-6 mt-6 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <p class="text-green-800 dark:text-green-200">{{ session('message') }}</p>
            </div>
        @endif
        
        <form wire:submit="save" class="p-6 space-y-6">
            
            <!-- Privacy Settings -->
            <div>
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Privacy Settings</h3>
                
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                        <div>
                            <label for="is_public" class="font-medium text-gray-900 dark:text-white">
                                Public Profile
                            </label>
                            <p class="text-sm text-gray-500 dark:text-gray-400">
                                Anyone can view your profile and activity
                            </p>
                        </div>
                        <input type="checkbox" id="is_public" wire:model="is_public" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    </div>
                    
                    <div class="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                        <div>
                            <label for="show_email" class="font-medium text-gray-900 dark:text-white">
                                Show Email Address
                            </label>
                            <p class="text-sm text-gray-500 dark:text-gray-400">
                                Display your email on your profile
                            </p>
                        </div>
                        <input type="checkbox" id="show_email" wire:model="show_email" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    </div>
                    
                    <div class="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                        <div>
                            <label for="show_joined_date" class="font-medium text-gray-900 dark:text-white">
                                Show Joined Date
                            </label>
                            <p class="text-sm text-gray-500 dark:text-gray-400">
                                Display when you joined on your profile
                            </p>
                        </div>
                        <input type="checkbox" id="show_joined_date" wire:model="show_joined_date" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    </div>
                    
                    <div class="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                        <div>
                            <label for="allow_comments" class="font-medium text-gray-900 dark:text-white">
                                Allow Profile Comments
                            </label>
                            <p class="text-sm text-gray-500 dark:text-gray-400">
                                Let others leave comments on your profile
                            </p>
                        </div>
                        <input type="checkbox" id="allow_comments" wire:model="allow_comments" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    </div>
                </div>
            </div>
            
            <!-- Account Information -->
            <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Account Information</h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="text-sm text-gray-500 dark:text-gray-400">Username</div>
                        <div class="font-medium text-gray-900 dark:text-white">{{ $user->name }}</div>
                    </div>
                    
                    <div class="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="text-sm text-gray-500 dark:text-gray-400">Email</div>
                        <div class="font-medium text-gray-900 dark:text-white">{{ $user->email }}</div>
                    </div>
                    
                    <div class="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="text-sm text-gray-500 dark:text-gray-400">Member Since</div>
                        <div class="font-medium text-gray-900 dark:text-white">{{ $user->created_at->format('F j, Y') }}</div>
                    </div>
                    
                    <div class="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="text-sm text-gray-500 dark:text-gray-400">Profile Status</div>
                        <div class="font-medium">
                            @if($profile->is_public)
                                <span class="text-green-600 dark:text-green-400">Public</span>
                            @else
                                <span class="text-yellow-600 dark:text-yellow-400">Private</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="flex justify-between items-center pt-6 border-t border-gray-200 dark:border-gray-700">
                <a href="{{ route('socialbase.profile.show', ['user' => $user->id]) }}" 
                   class="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                    ← Back to Profile
                </a>
                
                <div class="space-x-3">
                    <a href="{{ route('socialbase.profile.edit') }}" 
                       class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                        Edit Profile
                    </a>
                    <button type="submit" 
                            class="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
                            wire:loading.attr="disabled">
                        <span wire:loading.remove>Save Settings</span>
                        <span wire:loading>Saving...</span>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>