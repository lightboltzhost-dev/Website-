<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl shadow-xl max-w-4xl mx-auto">
        <div class="p-6 border-b border-gray-700/50">
            <h1 class="text-3xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent flex items-center">
                <i class="ri-edit-line mr-3"></i>
                Edit Profile
            </h1>
            <p class="text-gray-400 mt-2">Update your profile information and settings</p>
        </div>
        
        <form wire:submit="save" class="p-8 space-y-6">
            <!-- Basic Information -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="display_name" class="block text-sm font-semibold text-gray-300 mb-3">
                        Display Name
                    </label>
                    <input type="text" id="display_name" wire:model="display_name" 
                           class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white placeholder-gray-400 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 hover:bg-gray-700/70"
                           placeholder="Enter display name (optional)">
                    @error('display_name') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
                </div>
                
                <div>
                    <label for="location" class="block text-sm font-semibold text-gray-300 mb-3">
                        Location
                    </label>
                    <input type="text" id="location" wire:model="location" 
                           class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white placeholder-gray-400 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 hover:bg-gray-700/70"
                           placeholder="Enter your location (optional)">
                    @error('location') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
                </div>
            </div>
            
            <div>
                <label for="website" class="block text-sm font-semibold text-gray-300 mb-3">
                    Website
                </label>
                <input type="url" id="website" wire:model="website" 
                       class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white placeholder-gray-400 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 hover:bg-gray-700/70"
                       placeholder="https://example.com">
                @error('website') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
            </div>
            
            <div>
                <label for="bio" class="block text-sm font-semibold text-gray-300 mb-3">
                    Biography
                </label>
                <textarea id="bio" wire:model="bio" rows="5"
                          class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white placeholder-gray-400 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 hover:bg-gray-700/70"
                          placeholder="Tell others about yourself..."></textarea>
                @error('bio') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
            </div>
            
            <!-- Image Uploads -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-semibold text-gray-300 mb-3">
                        <i class="ri-user-3-line mr-1"></i> Avatar
                    </label>
                    @if($profile->avatar_url)
                        <div class="flex items-center space-x-4 mb-3">
                            <div class="w-20 h-20 rounded-full ring-4 ring-blue-500/20 overflow-hidden">
                                <img src="{{ $profile->avatar_url }}" alt="Current Avatar" class="w-full h-full object-cover">
                            </div>
                            <button type="button" wire:click="removeAvatar" 
                                    class="text-red-400 hover:text-red-300 text-sm font-medium transition-colors">
                                <i class="ri-delete-bin-line mr-1"></i> Remove Avatar
                            </button>
                        </div>
                    @endif
                    <input type="file" wire:model="avatar" accept="image/*" 
                           class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white rounded-xl file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 file:cursor-pointer transition-all duration-200 hover:bg-gray-700/70">
                    <p class="text-xs text-gray-400 mt-2"><i class="ri-information-line mr-1"></i> Max size: 5MB</p>
                    @error('avatar') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-300 mb-3">
                        <i class="ri-landscape-line mr-1"></i> Banner
                    </label>
                    @if($profile->banner_url)
                        <div class="flex items-center space-x-4 mb-3">
                            <div class="w-32 h-16 rounded-xl ring-4 ring-purple-500/20 overflow-hidden">
                                <img src="{{ $profile->banner_url }}" alt="Current Banner" class="w-full h-full object-cover">
                            </div>
                            <button type="button" wire:click="removeBanner" 
                                    class="text-red-400 hover:text-red-300 text-sm font-medium transition-colors">
                                <i class="ri-delete-bin-line mr-1"></i> Remove Banner
                            </button>
                        </div>
                    @endif
                    <input type="file" wire:model="banner" accept="image/*" 
                           class="w-full px-4 py-3 border border-gray-600/50 bg-gray-700/50 text-white rounded-xl file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 file:cursor-pointer transition-all duration-200 hover:bg-gray-700/70">
                    <p class="text-xs text-gray-400 mt-2"><i class="ri-information-line mr-1"></i> Max size: 10MB</p>
                    @error('banner') <span class="text-red-400 text-sm font-medium mt-2 block"><i class="ri-error-warning-line mr-1"></i>{{ $message }}</span> @enderror
                </div>
            </div>
            
            <!-- Privacy Settings -->
            <div class="border-t border-gray-700/50 pt-6">
                <h3 class="text-xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent mb-6">
                    <i class="ri-shield-check-line"></i> Privacy Settings
                </h3>
                
                <div class="space-y-4 bg-gray-700/30 p-6 rounded-xl">
                    <div class="flex items-center">
                        <input type="checkbox" id="is_public" wire:model="is_public" 
                               class="h-5 w-5 text-blue-600 focus:ring-blue-500 focus:ring-offset-gray-800 border-gray-600 rounded transition-all">
                        <label for="is_public" class="ml-3 block text-sm text-gray-300 font-medium">
                            <i class="ri-global-line mr-1"></i> Make profile public (visible to everyone)
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="show_email" wire:model="show_email" 
                               class="h-5 w-5 text-blue-600 focus:ring-blue-500 focus:ring-offset-gray-800 border-gray-600 rounded transition-all">
                        <label for="show_email" class="ml-3 block text-sm text-gray-300 font-medium">
                            <i class="ri-mail-line mr-1"></i> Show email address on profile
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="show_joined_date" wire:model="show_joined_date" 
                               class="h-5 w-5 text-blue-600 focus:ring-blue-500 focus:ring-offset-gray-800 border-gray-600 rounded transition-all">
                        <label for="show_joined_date" class="ml-3 block text-sm text-gray-300 font-medium">
                            <i class="ri-calendar-line mr-1"></i> Show joined date on profile
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="allow_comments" wire:model="allow_comments" 
                               class="h-5 w-5 text-blue-600 focus:ring-blue-500 focus:ring-offset-gray-800 border-gray-600 rounded transition-all">
                        <label for="allow_comments" class="ml-3 block text-sm text-gray-300 font-medium">
                            <i class="ri-chat-3-line mr-1"></i> Allow others to comment on profile
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="flex justify-end gap-4 pt-6 border-t border-gray-700/50">
                <a href="{{ route('socialbase.profile.show', ['user' => $user->id]) }}" 
                   class="px-6 py-3 bg-gray-700/50 hover:bg-gray-700/70 text-white rounded-xl font-semibold transition-all duration-300 hover:scale-105 inline-flex items-center border border-gray-600/50">
                    <i class="ri-close-line mr-2"></i> Cancel
                </a>
                <button type="submit" 
                        class="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg shadow-blue-500/25 disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center"
                        wire:loading.attr="disabled">
                    <span wire:loading.remove><i class="ri-save-line mr-2"></i> Save Changes</span>
                    <span wire:loading><i class="ri-loader-4-line mr-2 animate-spin"></i> Saving...</span>
                </button>
            </div>
        </form>
    </div>
</div>
