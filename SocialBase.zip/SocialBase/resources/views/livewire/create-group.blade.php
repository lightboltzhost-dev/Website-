<div>
    @include('socialbase::components.scrollbar-styles')
    
    <!-- Modal -->
    <div x-data="{ show: @entangle('showModal') }" 
         x-show="show" 
         x-cloak
         class="fixed inset-0 z-50 overflow-y-auto" 
         style="display: none;">
        
        <!-- Backdrop -->
        <div class="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" 
             @click="show = false"></div>
        
        <!-- Modal Content -->
        <div class="flex min-h-screen items-center justify-center p-4">
            <div class="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-2xl shadow-2xl transform transition-all"
                 @click.stop>
                
                <!-- Header -->
                <div class="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-900 dark:text-white">Create Group Chat</h3>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Start a conversation with multiple people</p>
                    </div>
                    <button @click="show = false" 
                            class="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
                
                <!-- Body -->
                <form wire:submit.prevent="createGroup" class="p-6 space-y-6">
                    <!-- Group Name -->
                    <div>
                        <label for="groupName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Group Name <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="groupName"
                            wire:model="groupName"
                            placeholder="Enter group name..."
                            class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 dark:text-white placeholder-gray-400 transition-all"
                        />
                        @error('groupName')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                    
                    <!-- Search Users -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Add Members <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            wire:model.live.debounce.300ms="searchQuery"
                            placeholder="Search users by name or email..."
                            class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 dark:text-white placeholder-gray-400 transition-all"
                        />
                        @error('selectedUsers')
                            <p class="mt-2 text-sm text-red-600 dark:text-red-400">{{ $message }}</p>
                        @enderror
                    </div>
                    
                    <!-- Selected Users -->
                    @if(count($selectedUsers) > 0)
                        <div class="flex flex-wrap gap-2 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                            <span class="text-sm font-medium text-blue-900 dark:text-blue-300">Selected ({{ count($selectedUsers) }}):</span>
                            @foreach($availableUsers as $user)
                                @if(in_array($user['id'], $selectedUsers))
                                    <span class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-sm">
                                        {{ $user['name'] }}
                                        <button 
                                            type="button"
                                            wire:click="toggleUser({{ $user['id'] }})" 
                                            class="hover:text-blue-900 dark:hover:text-blue-100">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                            </svg>
                                        </button>
                                    </span>
                                @endif
                            @endforeach
                        </div>
                    @endif
                    
                    <!-- Available Users List -->
                    <div class="max-h-64 overflow-y-auto socialbase-scroll border border-gray-200 dark:border-gray-700 rounded-lg">
                        @forelse($availableUsers as $user)
                            <div class="flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors border-b border-gray-100 dark:border-gray-700 last:border-0"
                                 wire:click="toggleUser({{ $user['id'] }})">
                                <div class="flex items-center gap-3">
                                    <!-- Avatar -->
                                    @if($user['avatar'])
                                        <img src="{{ $user['avatar'] }}" 
                                             alt="{{ $user['name'] }}" 
                                             class="w-10 h-10 rounded-full object-cover" />
                                    @else
                                        <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                                            {{ substr($user['name'], 0, 1) }}
                                        </div>
                                    @endif
                                    
                                    <div>
                                        <p class="font-medium text-gray-900 dark:text-white">{{ $user['name'] }}</p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400">{{ $user['email'] }}</p>
                                    </div>
                                </div>
                                
                                <!-- Checkbox -->
                                <div class="flex-shrink-0">
                                    <div class="w-5 h-5 rounded border-2 {{ in_array($user['id'], $selectedUsers) ? 'bg-blue-600 border-blue-600' : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600' }} flex items-center justify-center transition-all">
                                        @if(in_array($user['id'], $selectedUsers))
                                            <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/>
                                            </svg>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="p-8 text-center text-gray-500 dark:text-gray-400">
                                <svg class="w-12 h-12 mx-auto mb-2 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                                </svg>
                                <p>No users found</p>
                            </div>
                        @endforelse
                    </div>
                    
                    <!-- Actions -->
                    <div class="flex items-center justify-end gap-3 pt-4">
                        <button 
                            type="button"
                            @click="show = false"
                            class="px-6 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg font-medium transition-colors">
                            Cancel
                        </button>
                        <button 
                            type="submit"
                            class="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg font-medium shadow-lg hover:shadow-xl transition-all">
                            Create Group
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

