<style>
    /* Modern Scrollbar Styling for SocialBase */
    .socialbase-scroll::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    .socialbase-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .socialbase-scroll::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 100%);
        border-radius: 10px;
        transition: all 0.3s ease;
    }

    .socialbase-scroll::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #4f46e5 0%, #7c3aed 100%);
    }

    /* Firefox */
    .socialbase-scroll {
        scrollbar-width: thin;
        scrollbar-color: #6366f1 transparent;
    }

    /* Dark mode adjustments */
    .dark .socialbase-scroll::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #818cf8 0%, #a78bfa 100%);
    }

    .dark .socialbase-scroll::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 100%);
    }
</style>

