{{-- Empty view for unauthenticated users --}}

