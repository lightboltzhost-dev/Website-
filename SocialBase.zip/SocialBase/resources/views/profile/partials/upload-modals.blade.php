<!-- Avatar Upload Modal -->
<div id="avatarModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-96 max-w-full mx-4">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Upload Avatar</h3>
            <button onclick="closeAvatarUpload()" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <i class="ri-close-line text-xl"></i>
            </button>
        </div>
        
        <div class="mb-4">
            <input type="file" id="avatarFile" accept="image/*" class="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">
                Max size: 5MB. Allowed types: jpg, jpeg, png, gif, webp
            </p>
        </div>
        
        <div class="flex justify-end space-x-3">
            <button onclick="closeAvatarUpload()" class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                Cancel
            </button>
            <button onclick="uploadAvatar()" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                Upload
            </button>
        </div>
    </div>
</div>

<!-- Banner Upload Modal -->
<div id="bannerModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-96 max-w-full mx-4">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Upload Banner</h3>
            <button onclick="closeBannerUpload()" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                <i class="ri-close-line text-xl"></i>
            </button>
        </div>
        
        <div class="mb-4">
            <input type="file" id="bannerFile" accept="image/*" class="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white">
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">
                Max size: 10MB. Allowed types: jpg, jpeg, png, gif, webp
            </p>
        </div>
        
        <div class="flex justify-end space-x-3">
            <button onclick="closeBannerUpload()" class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                Cancel
            </button>
            <button onclick="uploadBanner()" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                Upload
            </button>
        </div>
    </div>
</div>