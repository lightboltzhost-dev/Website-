@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-4xl">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        <div class="p-6 border-b border-gray-200 dark:border-gray-700">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
                <i class="ri-settings-3-line mr-3"></i>
                Profile Settings
            </h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Manage your profile appearance and media</p>
        </div>
        
        <div class="p-6 space-y-8">
            <!-- Avatar Upload -->
            <div class="border border-gray-200 dark:border-gray-700 rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <i class="ri-user-3-line mr-2"></i>
                    Profile Avatar
                </h3>
                
                <div class="flex items-center space-x-6">
                    <div class="flex-shrink-0">
                        @if($profile->avatar_path)
                            <img src="{{ Storage::url($profile->avatar_path) }}" 
                                 alt="Current Avatar" 
                                 class="h-20 w-20 rounded-full object-cover border-2 border-gray-300 dark:border-gray-600">
                        @else
                            <div class="h-20 w-20 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
                                <i class="ri-user-line text-2xl text-gray-500 dark:text-gray-400"></i>
                            </div>
                        @endif
                    </div>
                    
                    <div class="flex-1">
                        <form action="{{ route('socialbase.profile.upload.avatar') }}" method="POST" enctype="multipart/form-data" class="space-y-3">
                            @csrf
                            <div>
                                <input type="file" id="avatar" name="avatar" accept="image/*" 
                                       class="block w-full text-sm text-gray-500 dark:text-gray-400
                                              file:mr-4 file:py-2 file:px-4
                                              file:rounded-lg file:border-0
                                              file:text-sm file:font-medium
                                              file:bg-blue-50 file:text-blue-700
                                              hover:file:bg-blue-100
                                              dark:file:bg-blue-900 dark:file:text-blue-300">
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                    PNG, JPG, GIF up to 5MB. Recommended: 400x400px
                                </p>
                            </div>
                            <div class="flex space-x-3">
                                <button type="submit" 
                                        class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors text-sm">
                                    Upload Avatar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Banner Upload -->
            <div class="border border-gray-200 dark:border-gray-700 rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <i class="ri-image-line mr-2"></i>
                    Profile Banner
                </h3>
                
                <div class="space-y-4">
                    @if($profile->banner_path)
                        <div class="relative">
                            <img src="{{ Storage::url($profile->banner_path) }}" 
                                 alt="Current Banner" 
                                 class="w-full h-32 object-cover rounded-lg border border-gray-300 dark:border-gray-600">
                        </div>
                    @else
                        <div class="w-full h-32 bg-gray-100 dark:bg-gray-700 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center">
                            <div class="text-center">
                                <i class="ri-image-add-line text-3xl text-gray-400 dark:text-gray-500"></i>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">No banner uploaded</p>
                            </div>
                        </div>
                    @endif
                    
                    <form action="{{ route('socialbase.profile.upload.banner') }}" method="POST" enctype="multipart/form-data" class="space-y-3">
                        @csrf
                        <div>
                            <input type="file" id="banner" name="banner" accept="image/*" 
                                   class="block w-full text-sm text-gray-500 dark:text-gray-400
                                          file:mr-4 file:py-2 file:px-4
                                          file:rounded-lg file:border-0
                                          file:text-sm file:font-medium
                                          file:bg-blue-50 file:text-blue-700
                                          hover:file:bg-blue-100
                                          dark:file:bg-blue-900 dark:file:text-blue-300">
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                PNG, JPG, GIF up to 10MB. Recommended: 1200x300px
                            </p>
                        </div>
                        <div class="flex space-x-3">
                            <button type="submit" 
                                    class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors text-sm">
                                Upload Banner
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                <a href="{{ route('socialbase.profile.show', ['user' => $user->id]) }}" 
                   class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                    Back to Profile
                </a>
                <a href="{{ route('socialbase.profile.edit') }}" 
                   class="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors">
                    Edit Profile Info
                </a>
            </div>
        </div>
    </div>
</div>
@endsection