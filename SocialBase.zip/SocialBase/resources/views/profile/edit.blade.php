@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-4xl">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        <div class="p-6 border-b border-gray-200 dark:border-gray-700">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
                <i class="ri-edit-line mr-3"></i>
                Edit Profile
            </h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Update your profile information and settings</p>
            
            @if(session('message'))
                <div class="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                    <div class="flex items-center">
                        <i class="ri-information-line text-blue-500 mr-2"></i>
                        <p class="text-blue-700 dark:text-blue-300">{{ session('message') }}</p>
                    </div>
                </div>
            @endif
        </div>
        
        <form action="{{ route('socialbase.profile.update') }}" method="POST" class="p-6 space-y-6">
            @csrf
            @method('PUT')
            
            <!-- Basic Information -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="display_name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Display Name
                    </label>
                    <input type="text" id="display_name" name="display_name" 
                           value="{{ old('display_name', $profile->display_name) }}"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                           placeholder="Enter display name (optional)">
                    @error('display_name') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>
                
                <div>
                    <label for="location" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Location
                    </label>
                    <input type="text" id="location" name="location" 
                           value="{{ old('location', $profile->location) }}"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                           placeholder="Enter your location (optional)">
                    @error('location') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                </div>
            </div>
            
            <div>
                <label for="website" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Website
                </label>
                <input type="url" id="website" name="website" 
                       value="{{ old('website', $profile->website) }}"
                       class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                       placeholder="https://example.com">
                @error('website') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            
            <div>
                <label for="bio" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Biography
                </label>
                <textarea id="bio" name="bio" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                          placeholder="Tell others about yourself...">{{ old('bio', $profile->bio) }}</textarea>
                @error('bio') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
            </div>
            
            <!-- Privacy Settings -->
            <div class="border-t border-gray-200 dark:border-gray-700 pt-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Privacy Settings</h3>
                
                <div class="space-y-4">
                    <div class="flex items-center">
                        <input type="checkbox" id="is_public" name="is_public" value="1" 
                               {{ old('is_public', $profile->is_public) ? 'checked' : '' }}
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="is_public" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            Make profile public (visible to everyone)
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="show_email" name="show_email" value="1" 
                               {{ old('show_email', $profile->show_email) ? 'checked' : '' }}
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="show_email" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            Show email address on profile
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="show_joined_date" name="show_joined_date" value="1" 
                               {{ old('show_joined_date', $profile->show_joined_date) ? 'checked' : '' }}
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="show_joined_date" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            Show joined date on profile
                        </label>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="allow_comments" name="allow_comments" value="1" 
                               {{ old('allow_comments', $profile->allow_comments) ? 'checked' : '' }}
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="allow_comments" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            Allow others to comment on profile
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                <a href="{{ route('socialbase.profile.show', ['user' => $user->id]) }}" 
                   class="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200">
                    Cancel
                </a>
                <button type="submit" 
                        class="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                    Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
@endsection