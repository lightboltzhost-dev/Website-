<div class="container mx-auto px-4 py-8">
    <!-- Profile Header -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden mb-8">
        <!-- Banner -->
        <div class="h-48 bg-gradient-to-r from-blue-500 to-purple-600 relative">
            @if($profile->banner_url)
                <img src="{{ $profile->banner_url }}" alt="Profile Banner" class="w-full h-full object-cover">
            @endif
            
            @if($isOwner)
                <div class="absolute top-4 right-4">
                    <a href="{{ route('socialbase.profile.edit') }}" class="bg-black bg-opacity-50 text-white px-3 py-2 rounded-lg hover:bg-opacity-70 transition-all">
                        <i class="ri-camera-line mr-2"></i>Change Banner
                    </a>
                </div>
            @endif
        </div>

        <!-- Profile Info -->
        <div class="px-6 py-6 relative">
            <div class="flex flex-col md:flex-row md:items-end md:space-x-6">
                <!-- Avatar -->
                <div class="relative -mt-16 mb-4 md:mb-0">
                    <img src="{{ $profile->avatar_url }}" alt="{{ $profile->display_name }}" 
                         class="w-32 h-32 rounded-full border-4 border-white dark:border-gray-800 shadow-lg">
                    
                    @if($isOwner)
                        <a href="{{ route('socialbase.profile.edit') }}" class="absolute bottom-2 right-2 bg-blue-500 text-white p-2 rounded-full hover:bg-blue-600 transition-colors">
                            <i class="ri-camera-line text-sm"></i>
                        </a>
                    @endif
                </div>

                <!-- Profile Details -->
                <div class="flex-1">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-900 dark:text-white">{{ $profile->display_name }}</h1>
                            
                            @if($profile->show_email && $profile->user->email)
                                <p class="text-gray-600 dark:text-gray-400 mt-1">
                                    <i class="ri-mail-line mr-2"></i>{{ $profile->user->email }}
                                </p>
                            @endif
                            
                            @if($profile->location)
                                <p class="text-gray-600 dark:text-gray-400 mt-1">
                                    <i class="ri-map-pin-line mr-2"></i>{{ $profile->location }}
                                </p>
                            @endif
                            
                            @if($profile->website)
                                <p class="text-gray-600 dark:text-gray-400 mt-1">
                                    <i class="ri-link mr-2"></i>
                                    <a href="{{ $profile->website }}" target="_blank" class="text-blue-500 hover:text-blue-600">
                                        {{ $profile->website }}
                                    </a>
                                </p>
                            @endif
                            
                            @if($profile->show_joined_date && $profile->user->created_at)
                                <p class="text-gray-500 dark:text-gray-400 text-sm mt-2">
                                    <i class="ri-calendar-line mr-2"></i>Joined {{ $profile->user->created_at->format('F Y') }}
                                </p>
                            @endif
                        </div>

                        @if($isOwner)
                            <div class="mt-4 md:mt-0 space-x-2">
                                <a href="{{ route('socialbase.profile.edit') }}" 
                                   class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors inline-flex items-center">
                                    <i class="ri-edit-line mr-2"></i>Edit Profile
                                </a>
                                <a href="{{ route('socialbase.profile.settings') }}" 
                                   class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors inline-flex items-center">
                                    <i class="ri-settings-line mr-2"></i>Settings
                                </a>
                            </div>
                        @endif
                    </div>

                    @if($profile->bio)
                        <div class="mt-4">
                            <p class="text-gray-700 dark:text-gray-300">{{ $profile->bio }}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Tabs -->
    <livewire:socialbase.profile-tabs :user="$user" :profile="$profile" />
    
    <!-- Profile Comments -->
    @if($profile->allow_comments)
        <livewire:socialbase.profile-comments :profile="$profile" :can-comment="$canComment" />
    @endif
</div>
</section>