# User Reporting System

The SocialBase extension includes a comprehensive user reporting and moderation system that allows users to report inappropriate profiles and enables administrators to review and take action on these reports.

## Features

### User Features
- **Report User Profiles**: Users can report other user profiles for various violations
- **Multiple Report Reasons**: Support for common violation types (spam, harassment, inappropriate content, impersonation, scam/fraud)
- **Additional Description**: Optional field for providing context
- **Confirmation Notification**: Automatic system message confirming report receipt
- **Decision Notification**: Automatic notification when admin reviews the report
- **Easy Access**: Report button in user profile dropdown menu

### Admin Features
- **Centralized Dashboard**: Dedicated admin resource in Profiles cluster
- **Pending Reports Badge**: Visual indicator of pending reports in navigation
- **Detailed Information**: View reported user, reporter, reason, and description
- **Flexible Status Options**: 
  - Pending Review (default)
  - Action Taken
  - No Action Required
  - Dismissed
- **Admin Notes**: Internal notes field for documenting actions taken
- **Automated Timestamps**: Tracks reviewer and review timestamp
- **Permission-Based Access**: Integrated with Paymenter's permission system

## How to Report a User

### For Users

1. **Navigate to User Profile**
   - Go to any user's profile page

2. **Access Report Option**
   - Click the dropdown menu (⋮) in the profile header
   - Select "Report User" from the menu

3. **Fill Out Report Form**
   - Select a reason from the dropdown:
     - Spam
     - Harassment
     - Inappropriate Content
     - Impersonation
     - Scam/Fraud
     - Other
   - Optionally add a detailed description (up to 1000 characters)

4. **Submit Report**
   - Click "Submit Report"
   - You'll receive a confirmation system message immediately

5. **Wait for Decision**
   - Moderation team will review your report
   - You'll receive a system message with the decision

## How to Review Reports

### For Administrators

1. **Access User Reports**
   - Go to Admin Panel
   - Navigate to "Profiles" cluster
   - Click "User Reports"

2. **View Pending Reports**
   - Reports are filtered to show pending only by default
   - Badge on navigation shows count of pending reports
   - Reports are sorted by date (newest first)

3. **Review Report Details**
   - Click the edit icon (pencil) on any report
   - View complete information:
     - Reported user's name and email
     - Reporter's name and email
     - Report reason and description
     - Timestamps

4. **Make a Decision**
   - Change status from "Pending Review" to:
     - **Action Taken**: When you've taken action against the user
     - **No Action Required**: When report doesn't violate policies
     - **Dismissed**: When report is invalid or spam
   - Optionally add internal admin notes
   - Click "Save"

5. **Reporter Notification**
   - Reporter automatically receives a system message with:
     - Report ID reference
     - Status update
     - Appropriate message based on decision
     - Thank you for contributing to community safety

## Database Schema

### User Reports Table (`ext_social_user_reports`)

| Column | Type | Description |
|--------|------|-------------|
| id | bigint | Primary key |
| reported_user_id | bigint | User being reported |
| reported_by | bigint | User who made the report |
| reason | string | Report reason (enum) |
| description | text | Additional details (nullable) |
| status | string | Review status (default: pending) |
| admin_notes | text | Internal admin notes (nullable) |
| reviewed_by | bigint | Admin who reviewed (nullable) |
| reviewed_at | timestamp | When reviewed (nullable) |
| created_at | timestamp | When reported |
| updated_at | timestamp | Last update |

## Events

The user reporting system dispatches the following events:

### `socialbase.user.reported`
**Dispatched when**: A user submits a report

**Data**: UserReport model instance

**Actions**:
- Sends confirmation system message to reporter
- Message includes report ID and reason

### `socialbase.user.report_reviewed`
**Dispatched when**: Admin changes report status from pending

**Data**: UserReport model instance

**Actions**:
- Sends decision system message to reporter
- Message content varies by status:
  - **Action Taken**: Confirms appropriate action was taken
  - **No Action**: Explains no violation was found
  - **Dismissed**: Indicates report was dismissed

## System Messages

### Confirmation Message
Sent immediately when user submits a report:

```
**Report Received - We're Reviewing It**

Thank you for reporting a user. We take all reports seriously and our moderation team will review it shortly.

Report Details:
- Reason: [Reason]
- Report ID: #[ID]

You will receive another message once our team has reviewed your report.
```

### Decision Messages

**Action Taken**:
```
**User Report Update - Decision Made**

Thank you for your report (ID: #[ID]) regarding [Username].

Our moderation team has reviewed your report.

Report Reason: [Reason]
Status: Action Taken

Appropriate action has been taken based on our community guidelines. We appreciate your help in keeping our community safe.

Thank you for contributing to a safer community.
```

**No Action Required**:
```
**User Report Update - Decision Made**

Thank you for your report (ID: #[ID]) regarding [Username].

Our moderation team has reviewed your report.

Report Reason: [Reason]
Status: No Action

After careful review, our team determined that no policy violation occurred. If you have additional concerns, please contact our support team.

Thank you for contributing to a safer community.
```

**Dismissed**:
```
**User Report Update - Decision Made**

Thank you for your report (ID: #[ID]) regarding [Username].

Our moderation team has reviewed your report.

Report Reason: [Reason]
Status: Dismissed

This report has been dismissed. If you believe this decision was made in error, please contact our support team.

Thank you for contributing to a safer community.
```

## Permissions

The user reporting system uses Paymenter's built-in permission system:

| Permission | Description |
|------------|-------------|
| `socialbase.reports.view` | View user reports in admin panel |
| `socialbase.reports.review` | Review and update report status |
| `socialbase.reports.delete` | Delete user reports |

Configure these permissions in: **Admin Panel → Administration → Roles**

## Technical Implementation

### Models
- **UserReport** (`Paymenter\Extensions\Others\SocialBase\Models\UserReport`)
  - Relationships: reportedUser, reporter, reviewer

### Livewire Components
- **ReportUser** (`socialbase.report-user`)
  - Handles report submission form
  - Validates input
  - Dispatches events

### Admin Resources
- **UserReportResource**
  - Located in: `Admin/Resources/UserReportResource.php`
  - Cluster: ProfilesCluster
  - Pages: List, View, Edit

### Policies
- **UserReportPolicy**
  - Controls admin access to reports
  - Enforces permission checks

### Event Listeners
Registered in `SocialBase.php`:
- `socialbase.user.reported` → Send confirmation
- `socialbase.user.report_reviewed` → Send decision

## Best Practices

### For Users
1. Only report genuine violations
2. Provide specific details in description
3. Select the most appropriate reason
4. Don't spam reports
5. Wait for moderation team response

### For Administrators
1. Review all reports promptly
2. Add admin notes for documentation
3. Be consistent in decisions
4. Take appropriate action for valid reports
5. Communicate clearly through system messages
6. Consider patterns (multiple reports on same user)

## Privacy & Security

- Report details are only visible to administrators
- Reported users are not notified of reports
- Reporter identity is protected
- Admin notes are internal only
- All actions are logged with timestamps
- Permission-based access control

## Integration with Other Systems

The user reporting system integrates with:
- **Messaging System**: For automated notifications
- **Permission System**: For access control
- **Event System**: For extensibility
- **Profile System**: For context and actions

## Future Enhancements

Potential future features:
- Email notifications for high-priority reports
- Automatic actions for repeat offenders
- Report analytics dashboard
- Appeal system for reported users
- Integration with ban/restriction system
- Bulk report handling

## Troubleshooting

### Reports Not Appearing in Admin
- Check extension is enabled
- Clear caches: `php artisan cache:clear`
- Verify migrations ran: check `ext_social_user_reports` table exists
- Check user has `socialbase.reports.view` permission

### System Messages Not Sending
- Verify MessagingHelper class exists
- Check event listeners are registered
- Review logs in storage/logs for errors
- Ensure system conversation is created

### Report Button Not Showing
- Check user is viewing another user's profile (not their own)
- Verify Livewire component is registered
- Clear view cache: `php artisan view:clear`
- Check browser console for JavaScript errors

## Support

For issues or questions:
1. Check this documentation
2. Review system logs (`storage/logs/laravel.log`)
3. Verify permissions and configuration
4. Check the SocialBase extension status

---

**Version**: 1.0  
**Last Updated**: October 1, 2025  
**Extension**: SocialBase for Paymenter

