<?php

namespace Paymenter\Extensions\Others\SocialBase\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class RequireProfile
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Only check for authenticated users
        if (!Auth::check()) {
            return $next($request);
        }

        $user = Auth::user();
        $profile = UserProfile::getForUser($user->id);

        // If no profile exists, redirect to create one
        if (!$profile) {
            return redirect()->route('socialbase.profile.edit')
                ->with('message', 'You need to set up your profile before using this feature.')
                ->with('message_type', 'info');
        }

        return $next($request);
    }
}
