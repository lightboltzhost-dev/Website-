<?php

namespace Paymenter\Extensions\Others\SocialBase\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Paymenter\Extensions\Others\SocialBase\Models\Message;
use Paymenter\Extensions\Others\SocialBase\Models\Conversation;

class AttachmentController
{
    public function download(Request $request, $messageId, $attachmentIndex)
    {
        // Check if user is authenticated
        if (!Auth::check()) {
            abort(403, 'You must be logged in to view attachments.');
        }

        // Find the message
        $message = Message::findOrFail($messageId);
        
        // Check if user is participant in the conversation
        $conversation = Conversation::findOrFail($message->conversation_id);
        if (!$conversation->hasParticipant(Auth::id())) {
            abort(403, 'You do not have access to this attachment.');
        }

        // Get the attachment
        $attachments = $message->attachments;
        if (!$attachments || !isset($attachments[$attachmentIndex])) {
            abort(404, 'Attachment not found.');
        }

        $attachment = $attachments[$attachmentIndex];
        
        // Check if file exists
        if (!Storage::disk('local')->exists($attachment['path'])) {
            abort(404, 'Attachment file not found.');
        }

        // Get file contents
        $file = Storage::disk('local')->get($attachment['path']);
        $mimeType = $attachment['type'] ?? 'application/octet-stream';
        $fileName = $attachment['name'] ?? 'attachment';

        // Return file response with appropriate headers
        return response($file, 200)
            ->header('Content-Type', $mimeType)
            ->header('Content-Disposition', 'inline; filename="' . $fileName . '"')
            ->header('Cache-Control', 'no-cache, no-store, must-revalidate')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }
}

