<?php

namespace Paymenter\Extensions\Others\SocialBase\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Traits\HasReactions;

class Message extends Model
{
    use SoftDeletes, HasReactions;

    protected $table = 'ext_social_messages';

    protected $fillable = [
        'conversation_id',
        'sender_id',
        'content',
        'attachments',
        'type',
        'is_system',
        'system_type',
        'metadata',
        'is_moderated',
        'moderation_status',
        'moderated_by',
        'moderated_at',
        'moderation_reason',
    ];

    protected $casts = [
        'is_system' => 'boolean',
        'is_moderated' => 'boolean',
        'moderated_at' => 'datetime',
        'metadata' => 'array',
        'attachments' => 'array',
    ];

    /**
     * Get the conversation
     */
    public function conversation(): BelongsTo
    {
        return $this->belongsTo(Conversation::class);
    }

    /**
     * Get the sender
     */
    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    /**
     * Get the moderator
     */
    public function moderator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'moderated_by');
    }

    /**
     * Get users who read this message
     */
    public function readBy(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'ext_social_message_reads', 'message_id', 'user_id')
            ->withPivot('read_at')
            ->withTimestamps();
    }

    /**
     * Get reports for this message
     */
    public function reports()
    {
        return $this->hasMany(\Paymenter\Extensions\Others\SocialBase\Models\MessageReport::class);
    }

    /**
     * Mark message as read by user
     */
    public function markAsReadBy($userId): void
    {
        if (!$this->readBy()->where('user_id', $userId)->exists()) {
            $this->readBy()->attach($userId, ['read_at' => now()]);
        }
    }

    /**
     * Check if message is read by user
     */
    public function isReadBy($userId): bool
    {
        return $this->readBy()->where('user_id', $userId)->exists();
    }

    /**
     * Scope for non-system messages
     */
    public function scopeUserMessages($query)
    {
        return $query->where('is_system', false);
    }

    /**
     * Scope for system messages
     */
    public function scopeSystemMessages($query)
    {
        return $query->where('is_system', true);
    }

    /**
     * Scope for flagged messages
     */
    public function scopeFlagged($query)
    {
        return $query->where('moderation_status', 'flagged');
    }

    /**
     * Scope for approved messages
     */
    public function scopeApproved($query)
    {
        return $query->where('moderation_status', 'approved');
    }
}
