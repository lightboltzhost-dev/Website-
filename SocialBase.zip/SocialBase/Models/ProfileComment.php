<?php

namespace Paymenter\Extensions\Others\SocialBase\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Traits\HasReactions;

class ProfileComment extends Model
{
    use SoftDeletes, HasReactions;

    protected $table = 'ext_social_profile_comments';

    protected $fillable = [
        'user_profile_id',
        'user_id',
        'parent_id',
        'content',
        'approved',
        'metadata',
    ];

    protected $casts = [
        'approved' => 'boolean',
        'metadata' => 'array',
    ];

    /**
     * Get the profile this comment belongs to
     */
    public function profile(): BelongsTo
    {
        return $this->belongsTo(UserProfile::class, 'user_profile_id');
    }

    /**
     * Get the user who wrote the comment
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get parent comment (for replies)
     */
    public function parent(): BelongsTo
    {
        return $this->belongsTo(ProfileComment::class, 'parent_id');
    }

    /**
     * Get replies to this comment
     */
    public function replies()
    {
        return $this->hasMany(ProfileComment::class, 'parent_id')->orderBy('created_at', 'asc');
    }

    // Reaction functionality is now provided by the HasReactions trait

    /**
     * Scope to get approved comments only
     */
    public function scopeApproved($query)
    {
        return $query->where('approved', true);
    }

    /**
     * Scope to get pending comments
     */
    public function scopePending($query)
    {
        return $query->where('approved', false);
    }

    /**
     * Scope to get top-level comments (not replies)
     */
    public function scopeTopLevel($query)
    {
        return $query->whereNull('parent_id');
    }

    /**
     * Check if comment can be edited by user
     */
    public function canBeEditedBy(?User $user = null): bool
    {
        if (!$user) {
            return false;
        }

        // Owner can edit within time limit (e.g., 15 minutes)
        if ($user->id === $this->user_id) {
            return $this->created_at->diffInMinutes(now()) < 15;
        }

        // Admins with permission can always edit
        return $user->hasPermission('socialbase.comments.update');
    }

        /**
     * Check if user can delete this comment
     */
    public function canBeDeletedBy(?User $user = null): bool
    {
        if (!$user) {
            return false;
        }

        // User can delete their own comment
        if ($user->id === $this->user_id) {
            return true;
        }

        // Profile owner can delete comments on their profile
        if ($user->id === $this->profile->user_id) {
            return true;
        }

        // Admins with permission can delete
        return $user->hasPermission('socialbase.comments.delete') ?? false;
    }



    /**
     * Check if user can edit this comment
     */
    public function canEdit(?User $user = null): bool
    {
        if (!$user) {
            return false;
        }

        // User can edit their own comment within 15 minutes
        if ($user->id === $this->user_id) {
            return $this->created_at->diffInMinutes(now()) <= 15;
        }

        // Admins can always edit
        return $user->hasPermission('socialbase.comments.edit') ?? false;
    }

    /**
     * Check if comment is editable (within time limit)
     */
    public function isEditable(): bool
    {
        return $this->created_at->diffInMinutes(now()) <= 15;
    }

    /**
     * Check if user owns this comment
     */
    public function isOwnedBy(?User $user = null): bool
    {
        return $user && $user->id === $this->user_id;
    }

    /**
     * Get formatted creation date
     */
    public function getFormattedDateAttribute(): string
    {
        return $this->created_at->diffForHumans();
    }

    /**
     * Get status as string
     */
    public function getStatusAttribute(): string
    {
        return $this->approved ? 'approved' : 'pending';
    }

    /**
     * Check if comment has been edited
     */
    public function getIsEditedAttribute(): bool
    {
        return $this->updated_at->gt($this->created_at->addMinute());
    }
}