<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin;

use Illuminate\Support\ServiceProvider;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;

class AdminServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Register Filament resources
        app('filament')->serving(function () {
            \Filament\Facades\Filament::registerResources([
                ProfileCommentResource::class,
                UserProfileResource::class,
            ]);
        });
    }
}