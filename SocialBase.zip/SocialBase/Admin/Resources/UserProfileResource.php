<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Placeholder;
use Filament\Tables;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Builder;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\ProfilesCluster;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Filament\Actions\EditAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\BulkActionGroup;

class UserProfileResource extends Resource
{
    protected static ?string $model = UserProfile::class;

    protected static string|\BackedEnum|null $navigationIcon = 'ri-user-line';

    protected static ?string $navigationLabel = 'User Profiles';

    protected static ?string $cluster = ProfilesCluster::class;

    protected static ?int $navigationSort = 10;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('user_name')
                    ->label('User')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record && $record->user) {
                            $component->state($record->user->name . ' (' . $record->user->email . ')');
                        } else {
                            $component->state('—');
                        }
                    })
                    ->disabled(),
                TextInput::make('display_name')
                    ->label('Display Name')
                    ->required()
                    ->maxLength(255),
                Textarea::make('bio')
                    ->label('Biography')
                    ->rows(4)
                    ->maxLength(1000),
                TextInput::make('location')
                    ->label('Location')
                    ->maxLength(255),
                TextInput::make('website')
                    ->label('Website')
                    ->url()
                    ->maxLength(255),
                Placeholder::make('avatar_preview')
                    ->label('Avatar Image')
                    ->content(function ($record) {
                        if (!$record || !$record->avatar_url) {
                            return 'No avatar uploaded';
                        }
                        return new \Illuminate\Support\HtmlString(
                            '<img src="' . e($record->avatar_url) . '" alt="Avatar" class="max-w-xs rounded-lg border border-gray-300 dark:border-gray-700" style="max-height: 150px; object-fit: contain;">'
                        );
                    }),
                Placeholder::make('banner_preview')
                    ->label('Banner Image')
                    ->content(function ($record) {
                        if (!$record || !$record->banner_url) {
                            return 'No banner uploaded';
                        }
                        return new \Illuminate\Support\HtmlString(
                            '<img src="' . e($record->banner_url) . '" alt="Banner" class="max-w-full rounded-lg border border-gray-300 dark:border-gray-700" style="max-height: 150px; object-fit: contain;">'
                        );
                    }),
                Toggle::make('is_public')
                    ->label('Public Profile')
                    ->default(true),
                Toggle::make('show_email')
                    ->label('Show Email on Profile')
                    ->default(false),
                Toggle::make('show_joined_date')
                    ->label('Show Joined Date')
                    ->default(true),
                Toggle::make('allow_comments')
                    ->label('Allow Comments')
                    ->default(true),
                TextInput::make('theme')
                    ->label('Profile Theme')
                    ->maxLength(255)
                    ->placeholder('default'),
                Select::make('moderation_status')
                    ->label('Moderation Status')
                    ->options([
                        'active' => 'Active',
                        'restricted' => 'Restricted',
                        'banned' => 'Banned',
                        'suspended' => 'Suspended',
                    ])
                    ->default('active')
                    ->required()
                    ->helperText('Overall moderation status'),
                Toggle::make('is_banned')
                    ->label('Banned')
                    ->helperText('Completely ban this user from using social features'),
                Toggle::make('upload_restricted')
                    ->label('Restrict Uploads')
                    ->helperText('Prevent user from uploading avatars/banners'),
                Toggle::make('comment_restricted')
                    ->label('Restrict Comments')
                    ->helperText('Prevent user from posting comments'),
                Toggle::make('profile_edit_restricted')
                    ->label('Restrict Profile Edits')
                    ->helperText('Prevent user from editing their profile'),
                Select::make('restriction_level')
                    ->label('Restriction Level')
                    ->options([
                        'none' => 'None',
                        'warning' => 'Warning',
                        'limited' => 'Limited',
                        'suspended' => 'Suspended',
                        'banned' => 'Banned',
                    ])
                    ->default('none')
                    ->helperText('Granular restriction level'),
                Textarea::make('restriction_reason')
                    ->label('Restriction Reason')
                    ->rows(3)
                    ->helperText('Public reason shown to the user for restrictions'),
                Textarea::make('moderation_notes')
                    ->label('Moderation Notes (Internal)')
                    ->rows(3)
                    ->helperText('Internal notes about moderation actions (not visible to user)'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),
                Tables\Columns\TextColumn::make('user.name')
                    ->label('User')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('user.email')
                    ->label('Email')
                    ->searchable(),
                Tables\Columns\TextColumn::make('display_name')
                    ->label('Display Name')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_public')
                    ->label('Public')
                    ->boolean(),
                Tables\Columns\IconColumn::make('allow_comments')
                    ->label('Comments')
                    ->boolean(),
                Tables\Columns\BadgeColumn::make('moderation_status')
                    ->label('Status')
                    ->colors([
                        'success' => 'active',
                        'warning' => 'restricted',
                        'danger' => 'banned',
                        'secondary' => 'suspended',
                    ]),
                Tables\Columns\IconColumn::make('is_banned')
                    ->label('Banned')
                    ->boolean(),
                Tables\Columns\BadgeColumn::make('restriction_level')
                    ->label('Restriction')
                    ->colors([
                        'success' => 'none',
                        'info' => 'warning',
                        'warning' => 'limited',
                        'danger' => 'suspended',
                        'danger' => 'banned',
                    ])
                    ->default('none'),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('moderation_status')
                    ->options([
                        'active' => 'Active',
                        'restricted' => 'Restricted',
                        'banned' => 'Banned',
                        'suspended' => 'Suspended',
                    ]),
                Tables\Filters\SelectFilter::make('restriction_level')
                    ->options([
                        'none' => 'None',
                        'warning' => 'Warning',
                        'limited' => 'Limited',
                        'suspended' => 'Suspended',
                        'banned' => 'Banned',
                    ]),
                Tables\Filters\TernaryFilter::make('is_banned')
                    ->label('Banned Users')
                    ->placeholder('All users')
                    ->trueLabel('Banned only')
                    ->falseLabel('Not banned'),
                Tables\Filters\TernaryFilter::make('is_public')
                    ->label('Public Profiles')
                    ->placeholder('All profiles')
                    ->trueLabel('Public only')
                    ->falseLabel('Private only'),
                Tables\Filters\TernaryFilter::make('upload_restricted')
                    ->label('Upload Restrictions')
                    ->trueLabel('Upload restricted')
                    ->falseLabel('Can upload'),
                Tables\Filters\TernaryFilter::make('comment_restricted')
                    ->label('Comment Restrictions')
                    ->trueLabel('Comment restricted')
                    ->falseLabel('Can comment'),
            ])
            ->defaultSort('created_at', 'desc')
            ->recordActions([
                EditAction::make(),
                DeleteAction::make()
                    ->requiresConfirmation()
                    ->modalDescription('Are you sure you want to delete this user profile? This will also delete all associated data including comments, reactions, and messages.')
                    ->modalHeading('Delete User Profile'),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make()
                        ->requiresConfirmation()
                        ->modalDescription('Are you sure you want to delete these user profiles? This will also delete all associated data including comments, reactions, and messages.')
                        ->modalHeading('Delete User Profiles'),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages\ListUserProfiles::route('/'),
            'view' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages\ViewUserProfile::route('/{record}'),
            'edit' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages\EditUserProfile::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['user']);
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::whereIn('moderation_status', ['restricted', 'banned', 'suspended'])->count();
        return $count > 0 ? (string) $count : null;
    }

    public static function canViewAny(): bool
    {
        $user = Auth::user();
        return $user && $user->hasPermission('socialbase.profiles.view');
    }
}
