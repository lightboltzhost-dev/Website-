<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\ConversationResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ConversationResource;

class ListConversations extends ListRecords
{
    protected static string $resource = ConversationResource::class;

    protected static ?string $title = 'Conversations';
}

