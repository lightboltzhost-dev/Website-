<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\ConversationResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ConversationResource;

class ViewConversation extends ViewRecord
{
    protected static string $resource = ConversationResource::class;

    protected static ?string $title = 'View Conversation';
}

