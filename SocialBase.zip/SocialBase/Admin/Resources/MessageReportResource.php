<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DateTimePicker;
use Filament\Tables;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Builder;
use Paymenter\Extensions\Others\SocialBase\Models\MessageReport;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\MessagingCluster;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Filament\Actions\EditAction;

class MessageReportResource extends Resource
{
    protected static ?string $model = MessageReport::class;

    protected static string|\BackedEnum|null $navigationIcon = 'ri-alarm-warning-line';

    protected static ?string $navigationLabel = 'Message Reports';

    protected static ?string $cluster = MessagingCluster::class;

    protected static ?int $navigationSort = 20;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('reporter_name')
                    ->label('Reported By')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reporter ? $record->reporter->name : '—');
                        }
                    })
                    ->disabled(),
                TextInput::make('reporter_email')
                    ->label('Reporter Email')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reporter ? $record->reporter->email : '—');
                        }
                    })
                    ->disabled(),
                Textarea::make('message_content')
                    ->label('Reported Message')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->message ? $record->message->content : 'Message deleted');
                        }
                    })
                    ->disabled()
                    ->rows(4),
                TextInput::make('message_sender')
                    ->label('Message Sender')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->message && $record->message->sender ? $record->message->sender->name : 'System');
                        }
                    })
                    ->disabled(),
                Select::make('reason')
                    ->label('Report Reason')
                    ->options([
                        'spam' => 'Spam',
                        'harassment' => 'Harassment',
                        'inappropriate' => 'Inappropriate Content',
                        'scam' => 'Scam/Phishing',
                        'other' => 'Other',
                    ])
                    ->disabled(),
                Textarea::make('description')
                    ->label('Description')
                    ->rows(3)
                    ->disabled(),
                Select::make('status')
                    ->label('Status')
                    ->options([
                        'pending' => 'Pending Review',
                        'reviewed' => 'Reviewed',
                        'dismissed' => 'Dismissed',
                    ])
                    ->required(),
                TextInput::make('message_moderation_status')
                    ->label('Message Status')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->message ? ucfirst($record->message->moderation_status ?? 'none') : '—');
                        }
                    })
                    ->disabled(),
                TextInput::make('reviewer_name')
                    ->label('Reviewed By')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reviewer ? $record->reviewer->name : 'Not reviewed');
                        }
                    })
                    ->disabled(),
                DateTimePicker::make('reviewed_at')
                    ->label('Reviewed At')
                    ->disabled(),
                DateTimePicker::make('created_at')
                    ->label('Reported At')
                    ->disabled(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),
                Tables\Columns\TextColumn::make('reporter.name')
                    ->label('Reported By')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('message.sender.name')
                    ->label('Message Sender')
                    ->searchable()
                    ->default('System'),
                Tables\Columns\TextColumn::make('message.content')
                    ->label('Message')
                    ->limit(40)
                    ->searchable(),
                Tables\Columns\BadgeColumn::make('reason')
                    ->label('Reason')
                    ->colors([
                        'warning' => 'spam',
                        'danger' => 'harassment',
                        'info' => 'inappropriate',
                        'danger' => 'scam',
                        'secondary' => 'other',
                    ]),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Status')
                    ->colors([
                        'warning' => 'pending',
                        'success' => 'reviewed',
                        'secondary' => 'dismissed',
                    ]),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Reported At')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'pending' => 'Pending',
                        'reviewed' => 'Reviewed',
                        'dismissed' => 'Dismissed',
                    ]),
                Tables\Filters\SelectFilter::make('reason')
                    ->options([
                        'spam' => 'Spam',
                        'harassment' => 'Harassment',
                        'inappropriate' => 'Inappropriate',
                        'scam' => 'Scam',
                        'other' => 'Other',
                    ]),
                Tables\Filters\Filter::make('pending')
                    ->query(fn (Builder $query): Builder => $query->where('status', 'pending'))
                    ->label('Pending Only')
                    ->default(),
            ])
            ->defaultSort('created_at', 'desc')
            ->recordActions([
                EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages\ListMessageReports::route('/'),
            'view' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages\ViewMessageReport::route('/{record}'),
            'edit' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages\EditMessageReport::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['reporter', 'message.sender', 'reviewer']);
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('status', 'pending')->count();
        return $count > 0 ? (string) $count : null;
    }

    public static function canViewAny(): bool
    {
        $user = Auth::user();
        return $user && $user->hasPermission('socialbase.reports.view');
    }
}

