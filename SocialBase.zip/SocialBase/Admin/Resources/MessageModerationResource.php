<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Tables;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Builder;
use Paymenter\Extensions\Others\SocialBase\Models\Message;
use Paymenter\Extensions\Others\SocialBase\Services\MessagingService;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\MessagingCluster;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Filament\Actions\EditAction;
use Filament\Actions\DeleteAction;
use Filament\Actions\ViewAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\Action;
use Filament\Actions\BulkAction;

class MessageModerationResource extends Resource
{
    protected static ?string $model = Message::class;

    protected static string|\BackedEnum|null $navigationIcon = 'ri-flag-line';

    protected static ?string $navigationLabel = 'Message Moderation';

    protected static ?string $cluster = MessagingCluster::class;

    protected static ?int $navigationSort = 10;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                       TextInput::make('sender_name')
                           ->label('Sender')
                           ->afterStateHydrated(function ($component, $state, $record) {
                               if ($record) {
                                   if ($record->is_system) {
                                       $component->state('System');
                                   } elseif ($record->sender) {
                                       $profile = \Paymenter\Extensions\Others\SocialBase\Models\UserProfile::where('user_id', $record->sender_id)->first();
                                       $component->state($profile?->display_name ?? $record->sender->name);
                                   } else {
                                       $component->state('—');
                                   }
                               }
                           })
                           ->disabled(),
                TextInput::make('sender_email')
                    ->label('Sender Email')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->sender ? $record->sender->email : '—');
                        }
                    })
                    ->disabled(),
                Textarea::make('recipients')
                    ->label('Recipients')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record && $record->conversation) {
                            $recipients = $record->conversation->participants()
                                ->where('user_id', '!=', $record->sender_id)
                                ->get()
                                ->map(fn($p) => $p->name)
                                ->join(', ');
                            $component->state($recipients ?: '—');
                        } else {
                            $component->state('—');
                        }
                    })
                    ->disabled()
                    ->rows(2),
                Textarea::make('content')
                    ->label('Message Content')
                    ->disabled()
                    ->rows(4),
                Select::make('moderation_status')
                    ->label('Moderation Status')
                    ->options([
                        'pending' => 'Pending',
                        'flagged' => 'Flagged',
                        'approved' => 'Approved',
                        'deleted' => 'Deleted',
                    ])
                    ->required(),
                Textarea::make('moderation_reason')
                    ->label('Moderation Reason')
                    ->rows(3)
                    ->placeholder('Enter reason for moderation...'),
                TextInput::make('conversation_id')
                    ->label('Conversation ID')
                    ->disabled(),
                Toggle::make('is_system')
                    ->label('System Message')
                    ->disabled(),
                TextInput::make('system_type')
                    ->label('System Type')
                    ->disabled()
                    ->visible(fn ($record) => $record && $record->is_system),
                TextInput::make('moderator_name')
                    ->label('Moderated By')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->moderator ? $record->moderator->name : 'Not moderated');
                        }
                    })
                    ->disabled(),
                DateTimePicker::make('moderated_at')
                    ->label('Moderated At')
                    ->disabled(),
                DateTimePicker::make('created_at')
                    ->label('Created At')
                    ->disabled(),
                Textarea::make('report_summary')
                    ->label('User Reports')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $reports = $record->reports()->with('reporter')->get();
                            if ($reports->isEmpty()) {
                                $component->state('No reports');
                            } else {
                                $summary = $reports->map(function($report) {
                                    return "[{$report->created_at->format('Y-m-d H:i')}] {$report->reporter->name}: {$report->reason}" . 
                                           ($report->description ? " - {$report->description}" : "");
                                })->join("\n\n");
                                $component->state($summary);
                            }
                        }
                    })
                    ->disabled()
                    ->rows(4)
                    ->helperText('Messages with 3+ reports are auto-flagged'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),
                Tables\Columns\TextColumn::make('conversation.id')
                    ->label('Conversation ID')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('sender_display_name')
                    ->label('Sender')
                    ->getStateUsing(function ($record) {
                        if ($record->is_system) {
                            return 'System';
                        }
                        if ($record->sender) {
                            $profile = \Paymenter\Extensions\Others\SocialBase\Models\UserProfile::where('user_id', $record->sender_id)->first();
                            return $profile?->display_name ?? $record->sender->name;
                        }
                        return '—';
                    })
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('content')
                    ->label('Content')
                    ->limit(50)
                    ->searchable(),
                Tables\Columns\BadgeColumn::make('moderation_status')
                    ->label('Status')
                    ->colors([
                        'warning' => 'flagged',
                        'success' => 'approved',
                        'danger' => 'deleted',
                    ]),
                Tables\Columns\IconColumn::make('is_system')
                    ->label('System')
                    ->boolean(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Sent At')
                    ->dateTime()
                    ->sortable(),
                Tables\Columns\TextColumn::make('moderator.name')
                    ->label('Moderated By')
                    ->default('—'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('moderation_status')
                    ->options([
                        'flagged' => 'Flagged',
                        'approved' => 'Approved',
                        'deleted' => 'Deleted',
                    ])
                    ->default('flagged'),
                Tables\Filters\SelectFilter::make('conversation_id')
                    ->label('Conversation')
                    ->query(function (Builder $query, array $state): Builder {
                        if (isset($state['value']) && filled($state['value'])) {
                            return $query->where('conversation_id', $state['value']);
                        }
                        return $query;
                    })
                    ->options(function () {
                        return \Paymenter\Extensions\Others\SocialBase\Models\Conversation::query()
                            ->orderBy('id')
                            ->pluck('id', 'id')
                            ->mapWithKeys(fn($id) => [$id => "Conversation #{$id}"])
                            ->toArray();
                    })
                    ->searchable()
                    ->preload(),
                Tables\Filters\Filter::make('is_system')
                    ->query(fn (Builder $query): Builder => $query->where('is_system', true))
                    ->label('System Messages Only'),
            ])
            ->defaultSort('created_at', 'desc')
            ->recordActions([
                ViewAction::make(),
                EditAction::make(),
                Action::make('approve')
                    ->label('Approve')
                    ->icon('ri-check-line')
                    ->color('success')
                    ->visible(fn ($record) => $record->moderation_status === 'flagged')
                    ->action(function ($record) {
                        $record->update([
                            'moderation_status' => 'approved',
                            'moderator_id' => Auth::id(),
                            'moderated_at' => now()
                        ]);
                        Notification::make()
                            ->title('Message approved')
                            ->success()
                            ->send();
                    })
                    ->requiresConfirmation(),
                Action::make('delete_message')
                    ->label('Delete')
                    ->icon('ri-delete-bin-line')
                    ->color('danger')
                    ->visible(fn ($record) => $record->moderation_status !== 'deleted')
                    ->action(function ($record) {
                        $record->update([
                            'moderation_status' => 'deleted',
                            'moderator_id' => Auth::id(),
                            'moderated_at' => now()
                        ]);
                        Notification::make()
                            ->title('Message deleted')
                            ->success()
                            ->send();
                    })
                    ->requiresConfirmation(),
                Action::make('view_conversation')
                    ->label('View Conversation')
                    ->icon('ri-chat-1-line')
                    ->color('info')
                    ->url(fn ($record) => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\ConversationResource::getUrl('view', ['record' => $record->conversation_id]))
                    ->openUrlInNewTab(),
                DeleteAction::make()
                    ->successNotificationTitle('Message deleted'),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    BulkAction::make('approve')
                        ->label('Approve Selected')
                        ->icon('ri-check-line')
                        ->color('success')
                        ->action(function ($records) {
                            $records->each->update([
                                'moderation_status' => 'approved',
                                'moderator_id' => Auth::id(),
                                'moderated_at' => now()
                            ]);
                            Notification::make()
                                ->title('Messages approved')
                                ->success()
                                ->send();
                        })
                        ->requiresConfirmation(),
                    BulkAction::make('delete')
                        ->label('Delete Selected')
                        ->icon('ri-delete-bin-line')
                        ->color('danger')
                        ->action(function ($records) {
                            $records->each->update([
                                'moderation_status' => 'deleted',
                                'moderator_id' => Auth::id(),
                                'moderated_at' => now()
                            ]);
                            Notification::make()
                                ->title('Messages deleted')
                                ->success()
                                ->send();
                        })
                        ->requiresConfirmation(),
                    DeleteBulkAction::make()
                        ->successNotificationTitle('Messages deleted'),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages\ListMessageModerations::route('/'),
            'view' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages\ViewMessageModeration::route('/{record}'),
            'edit' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages\EditMessageModeration::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['sender', 'conversation', 'moderator']);
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('moderation_status', 'flagged')->count();
        return $count > 0 ? (string) $count : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        $count = static::getModel()::where('moderation_status', 'flagged')->count();
        return $count > 5 ? 'danger' : ($count > 0 ? 'warning' : null);
    }

    public static function canViewAny(): bool
    {
        $user = Auth::user();
        return $user && $user->hasPermission('socialbase.messages.view');
    }
}
