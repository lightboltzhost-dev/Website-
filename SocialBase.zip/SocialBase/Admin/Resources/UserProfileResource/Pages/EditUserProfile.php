<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;

class EditUserProfile extends EditRecord
{
    protected static string $resource = UserProfileResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Remove virtual fields that are just for display
        unset($data['user_name']);
        unset($data['avatar_preview']);
        unset($data['banner_preview']);

        return $data;
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return 'Profile updated successfully';
    }
}
