<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;

class ListUserProfiles extends ListRecords
{
    protected static string $resource = UserProfileResource::class;
}
