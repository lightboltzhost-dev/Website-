<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;

class CreateUserProfile extends CreateRecord
{
    protected static string $resource = UserProfileResource::class;
    
    protected function mutateFormDataBeforeCreate(array $data): array
    {
        // Set default values for new profiles
        $data['is_public'] = false; // Private by default until setup
        $data['restriction_level'] = 'none';
        
        return $data;
    }
}