<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserProfileResource;

class ViewUserProfile extends ViewRecord
{
    protected static string $resource = UserProfileResource::class;
}
