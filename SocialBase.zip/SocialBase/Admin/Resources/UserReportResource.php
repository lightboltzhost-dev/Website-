<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DateTimePicker;
use Filament\Tables;
use Filament\Resources\Resource;
use Filament\Tables\Table;
use Filament\Schemas\Schema;
use Illuminate\Database\Eloquent\Builder;
use Paymenter\Extensions\Others\SocialBase\Models\UserReport;
use Paymenter\Extensions\Others\SocialBase\Admin\Clusters\ProfilesCluster;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Filament\Actions\EditAction;

class UserReportResource extends Resource
{
    protected static ?string $model = UserReport::class;

    protected static string|\BackedEnum|null $navigationIcon = 'ri-user-forbid-line';

    protected static ?string $navigationLabel = 'User Reports';

    protected static ?string $cluster = ProfilesCluster::class;

    protected static ?int $navigationSort = 30;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('reported_user_name')
                    ->label('Reported User')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reportedUser ? $record->reportedUser->name : '—');
                        }
                    })
                    ->disabled(),
                TextInput::make('reported_user_email')
                    ->label('Reported User Email')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reportedUser ? $record->reportedUser->email : '—');
                        }
                    })
                    ->disabled(),
                TextInput::make('reporter_name')
                    ->label('Reported By')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reporter ? $record->reporter->name : '—');
                        }
                    })
                    ->disabled(),
                TextInput::make('reporter_email')
                    ->label('Reporter Email')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reporter ? $record->reporter->email : '—');
                        }
                    })
                    ->disabled(),
                Select::make('reason')
                    ->label('Report Reason')
                    ->options([
                        'spam' => 'Spam',
                        'harassment' => 'Harassment',
                        'inappropriate' => 'Inappropriate',
                        'inappropriate_content' => 'Inappropriate Content',
                        'impersonation' => 'Impersonation',
                        'scam' => 'Scam/Fraud',
                        'other' => 'Other',
                    ])
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record && $record->reason) {
                            $component->state($record->reason);
                        }
                    })
                    ->disabled(),
                Textarea::make('description')
                    ->label('Description')
                    ->rows(3)
                    ->disabled(),
                Select::make('status')
                    ->label('Status')
                    ->options([
                        'pending' => 'Pending Review',
                        'action_taken' => 'Action Taken',
                        'no_action' => 'No Action Required',
                        'dismissed' => 'Dismissed',
                    ])
                    ->required(),
                Textarea::make('admin_notes')
                    ->label('Admin Notes')
                    ->rows(3)
                    ->helperText('Internal notes about the action taken (not visible to users)'),
                TextInput::make('reviewer_name')
                    ->label('Reviewed By')
                    ->afterStateHydrated(function ($component, $state, $record) {
                        if ($record) {
                            $component->state($record->reviewer ? $record->reviewer->name : 'Not reviewed');
                        }
                    })
                    ->disabled(),
                DateTimePicker::make('reviewed_at')
                    ->label('Reviewed At')
                    ->disabled(),
                DateTimePicker::make('created_at')
                    ->label('Reported At')
                    ->disabled(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),
                Tables\Columns\TextColumn::make('reportedUser.name')
                    ->label('Reported User')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('reporter.name')
                    ->label('Reported By')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\BadgeColumn::make('reason')
                    ->label('Reason')
                    ->colors([
                        'warning' => 'spam',
                        'danger' => 'harassment',
                        'info' => 'inappropriate_content',
                        'warning' => 'impersonation',
                        'danger' => 'scam',
                        'secondary' => 'other',
                    ])
                    ->formatStateUsing(fn (string $state): string => ucfirst(str_replace('_', ' ', $state))),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Status')
                    ->colors([
                        'warning' => 'pending',
                        'success' => 'action_taken',
                        'info' => 'no_action',
                        'secondary' => 'dismissed',
                    ])
                    ->formatStateUsing(fn (string $state): string => ucfirst(str_replace('_', ' ', $state))),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Reported At')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'pending' => 'Pending',
                        'action_taken' => 'Action Taken',
                        'no_action' => 'No Action',
                        'dismissed' => 'Dismissed',
                    ]),
                Tables\Filters\SelectFilter::make('reason')
                    ->options([
                        'spam' => 'Spam',
                        'harassment' => 'Harassment',
                        'inappropriate_content' => 'Inappropriate Content',
                        'impersonation' => 'Impersonation',
                        'scam' => 'Scam/Fraud',
                        'other' => 'Other',
                    ]),
                Tables\Filters\Filter::make('pending')
                    ->query(fn (Builder $query): Builder => $query->where('status', 'pending'))
                    ->label('Pending Only')
                    ->default(),
            ])
            ->defaultSort('created_at', 'desc')
            ->recordActions([
                EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages\ListUserReports::route('/'),
            'view' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages\ViewUserReport::route('/{record}'),
            'edit' => \Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages\EditUserReport::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->with(['reportedUser', 'reporter', 'reviewer']);
    }

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('status', 'pending')->count();
        return $count > 0 ? (string) $count : null;
    }

    public static function canViewAny(): bool
    {
        $user = Auth::user();
        return $user && $user->hasPermission('socialbase.reports.view');
    }
}

