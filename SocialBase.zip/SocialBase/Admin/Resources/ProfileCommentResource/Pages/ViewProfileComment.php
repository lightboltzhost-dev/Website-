<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;

class ViewProfileComment extends ViewRecord
{
    protected static string $resource = ProfileCommentResource::class;
}

