<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;

class EditProfileComment extends EditRecord
{
    protected static string $resource = ProfileCommentResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Remove virtual fields that are just for display
        unset($data['commenter_name']);
        unset($data['profile_owner']);
        unset($data['parent_comment']);
        unset($data['reactions_count']);

        return $data;
    }

    protected function afterSave(): void
    {
        // Check if comment was just approved
        $comment = $this->record;
        
        if ($comment->approved && $comment->wasChanged('approved')) {
            // Dispatch approval event
            event('socialbase.comment.approved', $comment);
        }
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return 'Comment updated successfully';
    }
}

