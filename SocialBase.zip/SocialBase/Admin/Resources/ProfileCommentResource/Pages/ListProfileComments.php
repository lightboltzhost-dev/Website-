<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\ProfileCommentResource;

class ListProfileComments extends ListRecords
{
    protected static string $resource = ProfileCommentResource::class;
}
