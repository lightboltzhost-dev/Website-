<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource;

class ViewMessageReport extends ViewRecord
{
    protected static string $resource = MessageReportResource::class;
}

