<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource;
use Illuminate\Support\Facades\Auth;

class EditMessageReport extends EditRecord
{
    protected static string $resource = MessageReportResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Remove virtual fields
        unset($data['reporter_name']);
        unset($data['reporter_email']);
        unset($data['message_content']);
        unset($data['message_sender']);
        unset($data['message_moderation_status']);
        unset($data['reviewer_name']);

        // Set reviewer and reviewed_at when status changes to reviewed
        if (isset($data['status']) && $data['status'] !== 'pending') {
            $data['reviewed_by'] = Auth::id();
            $data['reviewed_at'] = now();
        }

        return $data;
    }

    protected function afterSave(): void
    {
        // Check if report status was changed from pending
        $report = $this->record;
        
        if ($report->status !== 'pending' && $report->wasChanged('status')) {
            // Dispatch event for report review
            event('socialbase.message.report_reviewed', [$report, $report->status]);
        }
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return 'Report updated successfully';
    }
}

