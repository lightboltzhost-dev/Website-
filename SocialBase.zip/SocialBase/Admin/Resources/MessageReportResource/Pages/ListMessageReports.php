<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageReportResource;

class ListMessageReports extends ListRecords
{
    protected static string $resource = MessageReportResource::class;
}

