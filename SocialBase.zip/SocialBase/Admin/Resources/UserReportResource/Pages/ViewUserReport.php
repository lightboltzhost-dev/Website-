<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource;

class ViewUserReport extends ViewRecord
{
    protected static string $resource = UserReportResource::class;
}

