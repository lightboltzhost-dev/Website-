<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Auth;

class EditUserReport extends EditRecord
{
    protected static string $resource = UserReportResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Remove virtual fields that don't exist in the database
        unset($data['reported_user_name']);
        unset($data['reported_user_email']);
        unset($data['reporter_name']);
        unset($data['reviewer_name']);
        unset($data['reporter_email']);

        // If status is being changed from pending, set reviewer and reviewed_at
        if ($this->record->status === 'pending' && $data['status'] !== 'pending') {
            $data['reviewed_by'] = Auth::id();
            $data['reviewed_at'] = now();
        }

        return $data;
    }

    protected function afterSave(): void
    {
        // Only dispatch event if status changed from pending
        if ($this->record->wasChanged('status') && $this->record->getOriginal('status') === 'pending') {
            Event::dispatch('socialbase.user.report_reviewed', $this->record);
        }
    }
}

