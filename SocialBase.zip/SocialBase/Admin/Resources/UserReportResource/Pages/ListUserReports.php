<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\UserReportResource;

class ListUserReports extends ListRecords
{
    protected static string $resource = UserReportResource::class;
}

