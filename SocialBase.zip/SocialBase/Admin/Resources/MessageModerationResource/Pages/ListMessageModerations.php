<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages;

use Filament\Resources\Pages\ListRecords;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource;

class ListMessageModerations extends ListRecords
{
    protected static string $resource = MessageModerationResource::class;

    protected function getHeaderActions(): array
    {
        return [];
    }
}

