<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages;

use Filament\Resources\Pages\ViewRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource;

class ViewMessageModeration extends ViewRecord
{
    protected static string $resource = MessageModerationResource::class;
}

