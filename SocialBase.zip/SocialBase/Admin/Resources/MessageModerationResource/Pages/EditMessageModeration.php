<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource\Pages;

use Filament\Resources\Pages\EditRecord;
use Paymenter\Extensions\Others\SocialBase\Admin\Resources\MessageModerationResource;
use Paymenter\Extensions\Others\SocialBase\Services\MessagingService;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Auth;

class EditMessageModeration extends EditRecord
{
    protected static string $resource = MessageModerationResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Remove virtual fields that don't exist in database
        unset($data['sender_name']);
        unset($data['sender_email']);
        unset($data['moderator_name']);
        unset($data['recipients']);
        unset($data['report_summary']);
        
        // Track moderation
        $data['moderated_by'] = Auth::id();
        $data['moderated_at'] = now();
        $data['is_moderated'] = true;
        
        return $data;
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return 'Message moderation updated';
    }
}

