<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Paymenter\Extensions\Others\SocialBase\Models\Message;
use Paymenter\Extensions\Others\SocialBase\Models\UserReport;
use Paymenter\Extensions\Others\SocialBase\Models\MessageReport;
use Paymenter\Extensions\Others\SocialBase\Models\ProfileComment;

class SocialBaseModerationWidget extends BaseWidget
{
    protected static ?string $pollingInterval = '30s';
    
    protected static ?int $sort = 2;

    protected function getStats(): array
    {
        $flaggedMessages = Message::where('moderation_status', 'flagged')->count();
        $userReports = UserReport::where('status', 'pending')->count();
        $messageReports = MessageReport::where('status', 'pending')->count();
        $pendingComments = ProfileComment::where('moderation_status', 'pending')->count();
        $totalPending = $flaggedMessages + $userReports + $messageReports + $pendingComments;

        return [
            Stat::make('Flagged Messages', $flaggedMessages)
                ->description('Messages requiring review')
                ->descriptionIcon('ri-message-2-line')
                ->color($flaggedMessages > 5 ? 'danger' : ($flaggedMessages > 0 ? 'warning' : 'success'))
                ->url(route('filament.admin.resources.socialbase.message-moderation.index', ['tableFilters' => ['moderation_status' => ['value' => 'flagged']]])),
                
            Stat::make('User Reports', $userReports)
                ->description('User profile reports')
                ->descriptionIcon('ri-user-line')
                ->color($userReports > 3 ? 'danger' : ($userReports > 0 ? 'warning' : 'success'))
                ->url(route('filament.admin.resources.socialbase.user-reports.index', ['tableFilters' => ['status' => ['value' => 'pending']]])),
                
            Stat::make('Message Reports', $messageReports)
                ->description('Message content reports')
                ->descriptionIcon('ri-flag-line')
                ->color($messageReports > 3 ? 'danger' : ($messageReports > 0 ? 'warning' : 'success'))
                ->url(route('filament.admin.resources.socialbase.message-reports.index', ['tableFilters' => ['status' => ['value' => 'pending']]])),
                
            Stat::make('Pending Comments', $pendingComments)
                ->description('Profile comments awaiting approval')
                ->descriptionIcon('ri-chat-3-line')
                ->color($pendingComments > 5 ? 'danger' : ($pendingComments > 0 ? 'warning' : 'success'))
                ->url(route('filament.admin.resources.socialbase.profile-comments.index', ['tableFilters' => ['moderation_status' => ['value' => 'pending']]])),
                
            Stat::make('Total Pending', $totalPending)
                ->description('All SocialBase items needing attention')
                ->descriptionIcon('ri-alarm-warning-line')
                ->color($totalPending > 15 ? 'danger' : ($totalPending > 0 ? 'warning' : 'success')),
        ];
    }
}
