<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Clusters;

use Filament\Clusters\Cluster;

class MessagingCluster extends Cluster
{
    protected static string|\BackedEnum|null $navigationIcon = 'ri-message-3-line';

    protected static ?string $navigationLabel = 'Messaging';

    protected static ?int $navigationSort = 51;
	protected static string|\UnitEnum|null $navigationGroup = 'Social Base';

    public static function getNavigationLabel(): string
    {
        return 'Messaging';
    }
}

