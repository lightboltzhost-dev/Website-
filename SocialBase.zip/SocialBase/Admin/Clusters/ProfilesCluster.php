<?php

namespace Paymenter\Extensions\Others\SocialBase\Admin\Clusters;

use Filament\Clusters\Cluster;

class ProfilesCluster extends Cluster
{
    protected static string|\BackedEnum|null $navigationIcon = 'ri-user-line';

    protected static ?string $navigationLabel = 'Profiles';

    protected static ?int $navigationSort = 50;

	protected static string|\UnitEnum|null $navigationGroup = 'Social Base';

    public static function getNavigationLabel(): string
    {
        return 'Profiles';
    }
}

