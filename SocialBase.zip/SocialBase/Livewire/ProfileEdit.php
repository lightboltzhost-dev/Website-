<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class ProfileEdit extends Component
{
    use WithFileUploads;
    
    public $user;
    public $profile;
    
    // Form fields
    public $display_name = '';
    public $bio = '';
    public $location = '';
    public $website = '';
    public $is_public = true;
    public $show_email = false;
    public $show_joined_date = true;
    public $allow_comments = true;
    
    // File uploads
    public $avatar;
    public $banner;
    
    protected $rules = [
        'display_name' => 'nullable|string|max:255',
        'bio' => 'nullable|string|max:1000',
        'location' => 'nullable|string|max:255',
        'website' => 'nullable|url|max:255',
        'is_public' => 'boolean',
        'show_email' => 'boolean',
        'show_joined_date' => 'boolean',
        'allow_comments' => 'boolean',
        'avatar' => 'nullable|image|max:5120', // 5MB
        'banner' => 'nullable|image|max:10240', // 10MB
    ];
    
    public function mount()
    {
        $this->user = Auth::user();
        if (!$this->user) {
            return redirect()->route('login');
        }
        $this->profile = UserProfile::getForUser($this->user->id);
        
        // If no profile exists, create one for editing
        if (!$this->profile) {
            $this->profile = UserProfile::createForUser($this->user->id);
        }
        
        // Load current values
        $this->display_name = $this->profile->display_name;
        $this->bio = $this->profile->bio;
        $this->location = $this->profile->location;
        $this->website = $this->profile->website;
        $this->is_public = $this->profile->is_public;
        $this->show_email = $this->profile->show_email;
        $this->show_joined_date = $this->profile->show_joined_date;
        $this->allow_comments = $this->profile->allow_comments;
    }
    
    public function save()
    {
        $this->validate();
        
        $data = [
            'display_name' => $this->display_name,
            'bio' => $this->bio,
            'location' => $this->location,
            'website' => $this->website,
            'is_public' => $this->is_public,
            'show_email' => $this->show_email,
            'show_joined_date' => $this->show_joined_date,
            'allow_comments' => $this->allow_comments,
        ];
        
        // Handle avatar upload
        if ($this->avatar) {
            // Delete old avatar
            if ($this->profile->avatar_path) {
                Storage::delete($this->profile->avatar_path);
            }
            
            $data['avatar_path'] = $this->avatar->store('socialbase/avatars', 'public');
        }
        
        // Handle banner upload
        if ($this->banner) {
            // Delete old banner
            if ($this->profile->banner_path) {
                Storage::delete($this->profile->banner_path);
            }
            
            $data['banner_path'] = $this->banner->store('socialbase/banners', 'public');
        }
        
        $this->profile->update($data);
        
        $this->dispatch('success', 'Profile updated successfully!');
        
        // Redirect to profile view
        return redirect()->route('socialbase.profile.show', ['user' => $this->user->id]);
    }
    
    public function removeAvatar()
    {
        if ($this->profile->avatar_path) {
            Storage::delete($this->profile->avatar_path);
            $this->profile->update(['avatar_path' => null]);
            $this->dispatch('success', 'Avatar removed successfully!');
        }
    }
    
    public function removeBanner()
    {
        if ($this->profile->banner_path) {
            Storage::delete($this->profile->banner_path);
            $this->profile->update(['banner_path' => null]);
            $this->dispatch('success', 'Banner removed successfully!');
        }
    }
    
    public function render()
    {
        return view('socialbase::livewire.profile-edit');
    }
}