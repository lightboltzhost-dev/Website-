<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class ProfileSettings extends Component
{
    public $user;
    public $profile;
    
    // Settings
    public $is_public = true;
    public $show_email = false;
    public $show_joined_date = true;
    public $allow_comments = true;
    
    public function mount()
    {
        $this->user = Auth::user();
        if (!$this->user) {
            return redirect()->route('login');
        }
        $this->profile = UserProfile::getForUser($this->user->id);
        
        // If no profile exists, create one for settings
        if (!$this->profile) {
            $this->profile = UserProfile::createForUser($this->user->id);
        }
        
        // Load current settings
        $this->is_public = $this->profile->is_public;
        $this->show_email = $this->profile->show_email;
        $this->show_joined_date = $this->profile->show_joined_date;
        $this->allow_comments = $this->profile->allow_comments;
    }
    
    public function save()
    {
        $this->profile->update([
            'is_public' => $this->is_public,
            'show_email' => $this->show_email,
            'show_joined_date' => $this->show_joined_date,
            'allow_comments' => $this->allow_comments,
        ]);
        
        session()->flash('message', 'Settings updated successfully!');
    }
    
    public function render()
    {
        return view('socialbase::livewire.profile-settings');
    }
}