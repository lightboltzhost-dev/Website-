<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Helpers\MessagingHelper;

class ReportMessage extends Component
{
    public $messageId;
    public $showModal = false;
    public $reason = 'spam';
    public $description = '';

    protected $rules = [
        'reason' => 'required|in:spam,harassment,inappropriate,scam,other',
        'description' => 'nullable|string|max:500',
    ];

    public function mount($messageId)
    {
        $this->messageId = $messageId;
    }

    public function openModal()
    {
        $this->showModal = true;
    }

    public function closeModal()
    {
        $this->showModal = false;
        $this->reset(['reason', 'description']);
    }

    public function submitReport()
    {
        if (!Auth::check()) {
            $this->dispatch('error', 'You must be logged in to report messages.');
            return;
        }

        $this->validate();

        try {
            MessagingHelper::reportMessage(
                $this->messageId,
                Auth::id(),
                $this->reason,
                $this->description
            );

            $this->closeModal();
            $this->dispatch('success', 'Report submitted successfully. Our team will review it shortly.');
        } catch (\Exception $e) {
            $this->dispatch('error', 'Failed to submit report. Please try again.');
        }
    }

    public function render()
    {
        return view('socialbase::livewire.report-message');
    }
}

