<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Paymenter\Extensions\Others\SocialBase\Models\UserReport;

class ReportUser extends Component
{
    public $userId;
    public $showModal = false;
    public $reason = 'harassment';
    public $description = '';

    protected $listeners = ['open-report-modal' => 'openModal'];

    protected $rules = [
        'reason' => 'required|in:harassment,spam,inappropriate_content,impersonation,scam,other',
        'description' => 'nullable|string|max:500',
    ];

    public function mount($userId)
    {
        $this->userId = $userId;
    }

    public function openModal()
    {
        $this->showModal = true;
    }

    public function closeModal()
    {
        $this->showModal = false;
        $this->reset(['reason', 'description']);
    }

    public function submitReport()
    {
        if (!Auth::check()) {
            $this->dispatch('error', 'You must be logged in to report users.');
            return;
        }

        // Don't allow self-reporting
        if (Auth::id() == $this->userId) {
            $this->dispatch('error', 'You cannot report yourself.');
            return;
        }

        $this->validate();

        try {
            // Check if user already reported with this reason
            $existingReport = UserReport::where('reported_user_id', $this->userId)
                ->where('reported_by', Auth::id())
                ->where('reason', $this->reason)
                ->first();

            if ($existingReport) {
                $this->dispatch('error', 'You have already reported this user for this reason.');
                return;
            }

            $report = UserReport::create([
                'reported_user_id' => $this->userId,
                'reported_by' => Auth::id(),
                'reason' => $this->reason,
                'description' => $this->description,
                'status' => 'pending',
            ]);

            // Dispatch event for report creation
            Event::dispatch('socialbase.user.reported', $report);

            $this->closeModal();
            $this->dispatch('success', 'Report submitted successfully. Our team will review it shortly.');
        } catch (\Exception $e) {
            $this->dispatch('error', 'Failed to submit report. Please try again.');
        }
    }

    public function render()
    {
        return view('socialbase::livewire.report-user');
    }
}

