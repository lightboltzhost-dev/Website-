<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class ProfileView extends Component
{
	public $user;
    public $profile;
    public $isOwner = false;
    public $canComment = false;
    public $canReact = false;
    public $availableReactions = [];
    
    public function mount($user)
    {
        // Convert string ID to User model
        if (is_string($user)) {
            $this->user = \App\Models\User::findOrFail($user);
        } else {
            $this->user = $user;
        }
        
        $this->profile = UserProfile::getForUser($this->user->id);
        
        // If no profile exists, redirect to create one
        if (!$this->profile) {
            return redirect()->route('socialbase.profile.edit');
        }
        
        // Check if current user can view this profile
        $currentUser = Auth::user(); // This will be null for guest users
        if (!$this->profile->isViewableBy($currentUser)) {
            abort(403, 'This profile is private and you do not have permission to view it.');
        }
        
        $this->isOwner = Auth::check() && Auth::id() === $this->user->id;
        $this->canComment = Auth::check() && $this->profile->allowsComments() && Auth::id() !== $this->user->id;
        $this->canReact = Auth::check() && !$this->isOwner && $this->profile->isViewableBy(Auth::user());
        $this->availableReactions = \Paymenter\Extensions\Others\SocialBase\Models\Reaction::getAvailableTypes('social');
    }
    
    public function render()
    {
        return view('socialbase::livewire.profile-view');
    }
}