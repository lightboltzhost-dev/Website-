<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\Conversation;
use App\Models\User;

class CreateGroup extends Component
{
    public $showModal = false;
    public $groupName = '';
    public $selectedUsers = [];
    public $searchQuery = '';
    public $availableUsers = [];

    protected $listeners = ['open-create-group' => 'openModal'];

    protected $rules = [
        'groupName' => 'required|string|min:3|max:100',
        'selectedUsers' => 'required|array|min:1',
        'selectedUsers.*' => 'exists:users,id',
    ];

    protected $messages = [
        'groupName.required' => 'Group name is required.',
        'groupName.min' => 'Group name must be at least 3 characters.',
        'groupName.max' => 'Group name cannot exceed 100 characters.',
        'selectedUsers.required' => 'Select at least one user to add to the group.',
        'selectedUsers.min' => 'Select at least one user to add to the group.',
    ];

    public function mount()
    {
        $this->loadAvailableUsers();
    }

    public function openModal()
    {
        $this->showModal = true;
        $this->resetFields();
        $this->loadAvailableUsers();
    }

    public function closeModal()
    {
        $this->showModal = false;
        $this->resetFields();
    }

    public function resetFields()
    {
        $this->groupName = '';
        $this->selectedUsers = [];
        $this->searchQuery = '';
        $this->resetValidation();
    }

    public function loadAvailableUsers()
    {
        $query = User::where('id', '!=', Auth::id());

        if ($this->searchQuery) {
            $query->where(function ($q) {
                $q->where('name', 'like', '%' . $this->searchQuery . '%')
                  ->orWhere('email', 'like', '%' . $this->searchQuery . '%');
            });
        }

        $this->availableUsers = $query->limit(20)->get()->map(function ($user) {
            $profile = \Paymenter\Extensions\Others\SocialBase\Models\UserProfile::where('user_id', $user->id)->first();
            return [
                'id' => $user->id,
                'name' => $profile?->display_name ?? $user->name,
                'email' => $user->email,
                'avatar' => $profile?->avatar_url ?? $user->avatar,
            ];
        })->toArray();
    }

    public function updatedSearchQuery()
    {
        $this->loadAvailableUsers();
    }

    public function toggleUser($userId)
    {
        if (in_array($userId, $this->selectedUsers)) {
            $this->selectedUsers = array_diff($this->selectedUsers, [$userId]);
        } else {
            $this->selectedUsers[] = $userId;
        }
    }

    public function createGroup()
    {
        $this->validate();

        // Create group conversation
        $conversation = Conversation::create([
            'type' => 'group',
            'subject' => $this->groupName,
            'created_by' => Auth::id(),
        ]);

        // Add creator and selected users as participants
        $participants = array_merge([Auth::id()], $this->selectedUsers);
        $conversation->participants()->attach($participants);

        // Send system message to all participants
        $message = \Paymenter\Extensions\Others\SocialBase\Models\Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => null,
            'content' => "**Group Created**\n\n" . Auth::user()->name . " created the group \"" . $this->groupName . "\"",
            'type' => 'system',
            'is_system' => true,
            'system_type' => 'group_created',
            'metadata' => [],
        ]);
        
        // Update conversation last message time
        $conversation->update(['last_message_at' => now()]);

        $this->closeModal();
        $this->dispatch('groupCreated', $conversation->id);
        $this->dispatch('success', 'Group created successfully!');
    }

    public function render()
    {
        return view('socialbase::livewire.create-group');
    }
}

