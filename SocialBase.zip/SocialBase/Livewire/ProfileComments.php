<?php

namespace Paymenter\Extensions\Others\SocialBase\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;
use Paymenter\Extensions\Others\SocialBase\Models\ProfileComment;

class ProfileComments extends Component
{
    public UserProfile $profile;
    public bool $canComment;
    public $newComment = '';
    public $replyingTo = null;
    public $replyContent = '';
    public $editingComment = null;
    public $editContent = '';
    
    protected $rules = [
        'newComment' => 'required|string|min:3|max:1000',
        'replyContent' => 'required|string|min:3|max:1000',
        'editContent' => 'required|string|min:3|max:1000',
    ];
    
    public function mount(UserProfile $profile, bool $canComment = false)
    {
        $this->profile = $profile;
        $this->canComment = $canComment;
    }
    
    public function submitComment()
    {
        if (!$this->canComment) {
            $this->dispatch('error', 'You cannot comment on this profile.');
            return;
        }
        
        $this->validate(['newComment' => $this->rules['newComment']]);
        
        // Get auto-approval setting
        $autoApprove = $this->getAutoApproveComments();
        
        $comment = ProfileComment::create([
            'user_profile_id' => $this->profile->id,
            'user_id' => Auth::id(),
            'content' => $this->newComment,
            'approved' => $autoApprove,
            'metadata' => [
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ],
        ]);
        
        // Dispatch event for comment creation
        if ($autoApprove) {
            event('socialbase.comment.approved', $comment);
        } else {
            event('socialbase.comment.created', $comment);
        }
        
        $this->newComment = '';
        
        $message = $autoApprove 
            ? 'Comment posted successfully!' 
            : 'Comment submitted for approval.';
            
        $this->dispatch('success', $message);
    }
    
    public function startReply($commentId)
    {
        $this->replyingTo = $commentId;
        $this->replyContent = '';
    }
    
    public function cancelReply()
    {
        $this->replyingTo = null;
        $this->replyContent = '';
    }
    
    public function submitReply()
    {
        if (!$this->canComment) {
            $this->dispatch('error', 'You cannot comment on this profile.');
            return;
        }
        
        $this->validate(['replyContent' => $this->rules['replyContent']]);
        
        // Get auto-approval setting
        $autoApprove = $this->getAutoApproveComments();
        
        $comment = ProfileComment::create([
            'user_profile_id' => $this->profile->id,
            'user_id' => Auth::id(),
            'parent_id' => $this->replyingTo,
            'content' => $this->replyContent,
            'approved' => $autoApprove,
            'metadata' => [
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ],
        ]);
        
        // Dispatch event for comment creation
        if ($autoApprove) {
            event('socialbase.comment.approved', $comment);
        } else {
            event('socialbase.comment.created', $comment);
        }
        
        $this->cancelReply();
        
        $message = $autoApprove 
            ? 'Reply posted successfully!' 
            : 'Reply submitted for approval.';
            
        $this->dispatch('success', $message);
    }
    
    public function deleteComment($commentId)
    {
        $comment = ProfileComment::find($commentId);
        
        if (!$comment || !$comment->canBeDeletedBy(Auth::user())) {
            $this->dispatch('error', 'You cannot delete this comment.');
            return;
        }
        
        $comment->delete();
        $this->dispatch('success', 'Comment deleted successfully.');
    }
    
    public function startEdit($commentId)
    {
        $comment = ProfileComment::find($commentId);
        
        if (!$comment || !$comment->canEdit(Auth::user())) {
            $this->dispatch('error', 'You cannot edit this comment.');
            return;
        }
        
        $this->editingComment = $commentId;
        $this->editContent = $comment->content;
    }
    
    public function cancelEdit()
    {
        $this->editingComment = null;
        $this->editContent = '';
    }
    
    public function saveEdit()
    {
        $this->validate(['editContent' => $this->rules['editContent']]);
        
        $comment = ProfileComment::find($this->editingComment);
        
        if (!$comment || !$comment->canEdit(Auth::user())) {
            $this->dispatch('error', 'You cannot edit this comment.');
            return;
        }
        
        $comment->update(['content' => $this->editContent]);
        
        $this->cancelEdit();
        $this->dispatch('success', 'Comment updated successfully.');
    }
    
    public function toggleReaction($commentId, $type)
    {
        if (!Auth::check()) {
            $this->dispatch('error', 'You must be logged in to react.');
            return;
        }
        
        $comment = ProfileComment::find($commentId);
        if (!$comment) {
            return;
        }
        
        // Validate reaction type for social context
        $availableTypes = \Paymenter\Extensions\Others\SocialBase\Models\Reaction::getAvailableTypes('social');
        if (!array_key_exists($type, $availableTypes)) {
            $this->dispatch('error', 'Invalid reaction type.');
            return;
        }
        
        $user = Auth::user();
        $action = $comment->toggleReaction($user, $type);
        
        $messages = [
            'added' => 'Reaction added.',
            'updated' => 'Reaction updated.',
            'removed' => 'Reaction removed.',
        ];
        
        $this->dispatch('success', $messages[$action]);
    }
    
    /**
     * Get auto-approve comments setting
     */
    private function getAutoApproveComments(): bool
    {
        try {
            $extension = \App\Models\Extension::where('extension', 'SocialBase')->first();
            if ($extension && $extension->settings) {
                $setting = $extension->settings->where('key', 'require_approval_comments')->first();
                return $setting ? !(bool) $setting->value : true; // Invert because setting is "require approval"
            }
        } catch (\Exception $e) {
            // Fall back to default
        }
        
        return true; // Default to auto-approve
    }
    
    public function render()
    {
        $comments = $this->profile->approvedComments()
            ->topLevel()
            ->with(['user', 'replies.user', 'reactions'])
            ->get();
        
        // Load SocialBase profiles for all commenters
        $userIds = $comments->pluck('user_id')
            ->merge($comments->flatMap(function ($comment) {
                return $comment->replies->pluck('user_id');
            }))
            ->unique()
            ->toArray();
        
        $profiles = UserProfile::whereIn('user_id', $userIds)->get()->keyBy('user_id');
        
        // Get current user's profile
        $currentUserProfile = null;
        if (Auth::check()) {
            $currentUserProfile = UserProfile::where('user_id', Auth::id())->first();
        }
            
        return view('socialbase::livewire.profile-comments', [
            'comments' => $comments,
            'profiles' => $profiles,
            'currentUserProfile' => $currentUserProfile,
        ]);
    }
}