<?php

use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Others\SocialBase\Http\Controllers\ProfileController;
use Paymenter\Extensions\Others\SocialBase\Livewire\ProfileView;
use Paymenter\Extensions\Others\SocialBase\Livewire\ProfileEdit;
use Paymenter\Extensions\Others\SocialBase\Livewire\ProfileSettings;

Route::group(['middleware' => ['web']], function () {
    // Redirect /profile to logged-in user's profile
    Route::get('/profile', [ProfileController::class, 'redirectToOwnProfile'])->name('socialbase.profile.own')->middleware('auth');

    Route::prefix('profile')->name('socialbase.profile.')->group(function () {
        // Profile editing - specific routes must come BEFORE parameterized routes (using Livewire)
        Route::get('/edit', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileEdit::class)->name('edit')->middleware('auth');
        Route::get('/settings', \Paymenter\Extensions\Others\SocialBase\Livewire\ProfileSettings::class)->name('settings')->middleware('auth');
        
        // Profile viewing - using Livewire component (MUST be last due to {user} parameter)
        Route::get('/{user}', ProfileView::class)->name('show');    // Profile image uploads
    Route::post('/upload-avatar', [ProfileController::class, 'uploadAvatar'])->name('upload.avatar');
    Route::post('/upload-banner', [ProfileController::class, 'uploadBanner'])->name('upload.banner');
    Route::delete('/remove-avatar', [ProfileController::class, 'removeAvatar'])->name('remove.avatar');
    Route::delete('/remove-banner', [ProfileController::class, 'removeBanner'])->name('remove.banner');
    
    // Comment management
    Route::post('/{user}/comment', [ProfileController::class, 'storeComment'])->name('comment.store');
    Route::put('/comment/{comment}', [ProfileController::class, 'updateComment'])->name('comment.update');
    Route::delete('/comment/{comment}', [ProfileController::class, 'deleteComment'])->name('comment.delete');
    
    // Comment reactions
    Route::post('/comment/{comment}/reaction', [ProfileController::class, 'toggleReaction'])->name('comment.reaction.toggle');
    Route::get('/comment/{comment}/reactions', [ProfileController::class, 'getCommentReactions'])->name('comment.reactions');
    
    // Profile reactions
    Route::post('/{user}/reaction', [ProfileController::class, 'toggleProfileReaction'])->name('profile.reaction.toggle');
    Route::get('/{user}/reactions', [ProfileController::class, 'getProfileReactions'])->name('profile.reactions');
    });

    // API routes for AJAX requests
    Route::prefix('api/profile')->name('socialbase.api.profile.')->middleware('auth')->group(function () {
        Route::get('/{user}/stats', [ProfileController::class, 'getStats'])->name('stats');
        Route::get('/{user}/tabs', [ProfileController::class, 'getTabs'])->name('tabs');
        Route::get('/{user}/tab-content/{tab}', [ProfileController::class, 'getTabContent'])->name('tab.content');
    });

    // Messaging routes
    Route::prefix('messages')->name('socialbase.messages.')->middleware('auth')->group(function () {
        Route::get('/', \Paymenter\Extensions\Others\SocialBase\Livewire\MessagingInterface::class)->name('index');
        Route::get('/conversation/{conversationId}', \Paymenter\Extensions\Others\SocialBase\Livewire\MessagingInterface::class)->name('conversation');
        Route::get('/user/{recipientId}', \Paymenter\Extensions\Others\SocialBase\Livewire\MessagingInterface::class)->name('user');
        
        // Secure attachment download
        Route::get('/attachment/{messageId}/{attachmentIndex}', [\Paymenter\Extensions\Others\SocialBase\Http\Controllers\AttachmentController::class, 'download'])
            ->name('attachment.download');
    });
});