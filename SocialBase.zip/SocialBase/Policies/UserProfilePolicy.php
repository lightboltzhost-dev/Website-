<?php

namespace Paymenter\Extensions\Others\SocialBase\Policies;

use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\UserProfile;

class UserProfilePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('socialbase.profiles.view');
    }

    public function view(User $user, UserProfile $profile): bool
    {
        // Owner can always view their profile
        if ($user->id === $profile->user_id) {
            return true;
        }

        // Admin can view if they have permission
        if ($user->hasPermission('socialbase.profiles.view')) {
            return true;
        }

        // Check if profile is public
        return $profile->is_public;
    }

    public function create(User $user): bool
    {
        return $user->hasPermission('socialbase.profiles.create');
    }

    public function update(User $user, UserProfile $profile): bool
    {
        // Owner can always update their profile
        if ($user->id === $profile->user_id) {
            return true;
        }

        // Admin can update if they have permission
        return $user->hasPermission('socialbase.profiles.update');
    }

    public function delete(User $user, UserProfile $profile): bool
    {
        // Owner can delete their profile
        if ($user->id === $profile->user_id) {
            return true;
        }

        // Admin can delete if they have permission
        return $user->hasPermission('socialbase.profiles.delete');
    }

    public function moderate(User $user): bool
    {
        return $user->hasPermission('socialbase.profiles.moderate');
    }
}