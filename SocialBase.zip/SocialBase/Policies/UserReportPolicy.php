<?php

namespace Paymenter\Extensions\Others\SocialBase\Policies;

use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\UserReport;

class UserReportPolicy
{
    /**
     * Determine if user can view any reports
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('socialbase.reports.view');
    }

    /**
     * Determine if user can view the report
     */
    public function view(User $user, UserReport $report): bool
    {
        return $user->hasPermission('socialbase.reports.view');
    }

    /**
     * Determine if user can review reports
     */
    public function update(User $user, UserReport $report): bool
    {
        return $user->hasPermission('socialbase.reports.review');
    }

    /**
     * Determine if user can delete reports
     */
    public function delete(User $user, UserReport $report): bool
    {
        return $user->hasPermission('socialbase.reports.delete');
    }
}

