<?php

namespace Paymenter\Extensions\Others\SocialBase\Policies;

use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\Message;

class MessagePolicy
{
    /**
     * Determine if user can view any messages
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('socialbase.messages.view');
    }

    /**
     * Determine if user can view the message
     */
    public function view(User $user, Message $message): bool
    {
        return $user->hasPermission('socialbase.messages.view');
    }

    /**
     * Determine if user can moderate messages
     */
    public function moderate(User $user): bool
    {
        return $user->hasPermission('socialbase.messages.moderate');
    }

    /**
     * Determine if user can delete messages
     */
    public function delete(User $user, Message $message): bool
    {
        return $user->hasPermission('socialbase.messages.delete');
    }

    /**
     * Determine if user can restore deleted messages
     */
    public function restore(User $user, Message $message): bool
    {
        return $user->hasPermission('socialbase.messages.delete');
    }

    /**
     * Determine if user can permanently delete messages
     */
    public function forceDelete(User $user, Message $message): bool
    {
        return $user->hasPermission('socialbase.messages.delete');
    }
}

