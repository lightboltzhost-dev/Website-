<?php

namespace Paymenter\Extensions\Others\SocialBase\Policies;

use App\Models\User;
use Paymenter\Extensions\Others\SocialBase\Models\ProfileComment;

class ProfileCommentPolicy
{
    /**
     * Determine if user can view any comments (Admin)
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('socialbase.comments.view');
    }

    /**
     * Determine if user can view the comment (Admin)
     */
    public function view(User $user, ProfileComment $comment): bool
    {
        return $user->hasPermission('socialbase.comments.view');
    }

    /**
     * Determine if user can create comments
     */
    public function create(User $user): bool
    {
        return $user->hasPermission('socialbase.comments.create');
    }

    /**
     * Determine if user can update comments
     */
    public function update(User $user, ProfileComment $comment): bool
    {
        // Owner can update within time limit
        if ($user->id === $comment->user_id && $comment->isEditable()) {
            return true;
        }

        // Admin can update if they have permission
        return $user->hasPermission('socialbase.comments.update');
    }

    /**
     * Determine if user can delete comments
     */
    public function delete(User $user, ProfileComment $comment): bool
    {
        // Owner can delete their own comment
        if ($user->id === $comment->user_id) {
            return true;
        }

        // Profile owner can delete comments on their profile
        if ($comment->profile && $user->id === $comment->profile->user_id) {
            return true;
        }

        // Admin can delete if they have permission
        return $user->hasPermission('socialbase.comments.delete');
    }

    /**
     * Determine if user can moderate comments
     */
    public function moderate(User $user): bool
    {
        return $user->hasPermission('socialbase.comments.moderate');
    }
}
