<?php

namespace Paymenter\Extensions\Others\SocialBase\Helpers;

use Paymenter\Extensions\Others\SocialBase\Services\MessagingService;

/**
 * Helper class for other extensions to send messages
 */
class MessagingHelper
{
    /**
     * Send a system message to a user
     * 
     * @param int $userId User ID to send message to
     * @param string $content Message content
     * @param string $systemType Type of system message (e.g., 'order_update', 'payment_received', 'account_notification')
     * @param array $metadata Additional metadata to store with the message
     * @return \Paymenter\Extensions\Others\SocialBase\Models\Message
     * 
     * @example
     * MessagingHelper::sendSystemMessage(
     *     userId: 1,
     *     content: 'Your order #12345 has been completed',
     *     systemType: 'order_update',
     *     metadata: ['order_id' => 12345]
     * );
     */
    public static function sendSystemMessage(int $userId, string $content, string $systemType = 'general', array $metadata = [])
    {
        $service = new MessagingService();
        return $service->sendSystemMessage($userId, $content, $systemType, $metadata);
    }

    /**
     * Send a system message to multiple users
     * 
     * @param array $userIds Array of user IDs
     * @param string $content Message content
     * @param string $systemType Type of system message
     * @param array $metadata Additional metadata
     * @return array Array of created messages
     * 
     * @example
     * MessagingHelper::sendSystemMessageToUsers(
     *     userIds: [1, 2, 3],
     *     content: 'System maintenance scheduled for tomorrow',
     *     systemType: 'system_announcement'
     * );
     */
    public static function sendSystemMessageToUsers(array $userIds, string $content, string $systemType = 'general', array $metadata = [])
    {
        $service = new MessagingService();
        return $service->sendSystemMessageToUsers($userIds, $content, $systemType, $metadata);
    }

    /**
     * Send a direct message from one user to another
     * 
     * @param int $senderId Sender user ID
     * @param int $recipientId Recipient user ID
     * @param string $content Message content
     * @param array $metadata Additional metadata
     * @return \Paymenter\Extensions\Others\SocialBase\Models\Message
     */
    public static function sendDirectMessage(int $senderId, int $recipientId, string $content, array $metadata = [])
    {
        $service = new MessagingService();
        return $service->sendDirectMessage($senderId, $recipientId, $content, $metadata);
    }

    /**
     * Get unread message count for a user
     * 
     * @param int $userId
     * @return int
     */
    public static function getUnreadCount(int $userId): int
    {
        $service = new MessagingService();
        return $service->getUnreadCount($userId);
    }

    /**
     * Report a message
     * 
     * @param int $messageId Message ID to report
     * @param int $reportedBy User ID reporting the message
     * @param string $reason Reason for report (spam, harassment, inappropriate, etc.)
     * @param string|null $description Optional detailed description
     * @return \Paymenter\Extensions\Others\SocialBase\Models\MessageReport
     * 
     * @example
     * MessagingHelper::reportMessage(
     *     messageId: 123,
     *     reportedBy: 1,
     *     reason: 'spam',
     *     description: 'This message contains spam content'
     * );
     */
    public static function reportMessage(int $messageId, int $reportedBy, string $reason, ?string $description = null)
    {
        $service = new MessagingService();
        return $service->reportMessage($messageId, $reportedBy, $reason, $description);
    }

    /**
     * Check if messaging system is available
     * 
     * @return bool
     */
    public static function isAvailable(): bool
    {
        try {
            return class_exists('\Paymenter\Extensions\Others\SocialBase\Services\MessagingService') &&
                   \Illuminate\Support\Facades\Schema::hasTable('ext_social_messages');
        } catch (\Exception $e) {
            return false;
        }
    }
}

