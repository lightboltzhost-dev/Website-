<?php

namespace Paymenter\Extensions\Others\SocialBase\Helpers;

class MessageFormatter
{
    /**
     * Format message content with Discord-like markdown support
     * 
     * @param string $content
     * @return string
     */
    public static function format(string $content): string
    {
        // Escape HTML first
        $content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
        
        // Bold: **text** or __text__
        $content = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $content);
        $content = preg_replace('/__(.+?)__/', '<strong>$1</strong>', $content);
        
        // Italic: *text* or _text_
        $content = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $content);
        $content = preg_replace('/_(.+?)_/', '<em>$1</em>', $content);
        
        // Strikethrough: ~~text~~
        $content = preg_replace('/~~(.+?)~~/', '<del>$1</del>', $content);
        
        // Underline: __text__
        $content = preg_replace('/\|\|(.+?)\|\|/', '<span class="bg-gray-700 dark:bg-gray-600 hover:bg-transparent transition-colors cursor-pointer" title="Spoiler">$1</span>', $content);
        
        // Code inline: `code`
        $content = preg_replace('/`([^`]+)`/', '<code class="px-1.5 py-0.5 bg-gray-200 dark:bg-gray-700 rounded text-sm font-mono">$1</code>', $content);
        
        // Code block: ```code```
        $content = preg_replace('/```([^`]+)```/s', '<pre class="px-3 py-2 bg-gray-200 dark:bg-gray-700 rounded text-sm font-mono overflow-x-auto my-2"><code>$1</code></pre>', $content);
        
        // Links: [text](url)
        $content = preg_replace('/\[([^\]]+)\]\(([^\)]+)\)/', '<a href="$2" target="_blank" class="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 underline">$1</a>', $content);
        
        // Auto-link URLs
        $content = preg_replace('/(https?:\/\/[^\s<]+)/', '<a href="$1" target="_blank" class="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 underline break-all">$1</a>', $content);
        
        // Line breaks
        $content = nl2br($content);
        
        return $content;
    }
}

